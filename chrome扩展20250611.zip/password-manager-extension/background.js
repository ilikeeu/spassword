// background.js (Service Worker)

// 监听来自内容脚本的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'makeRequest') {
    console.log('Background: Received makeRequest. URL:', request.url, 'Options:', request.options); // 收到请求的日志
    fetch(request.url, request.options)
      .then(response => {
        console.log('Background: Fetch response received. Status:', response.status); // Fetch响应状态日志
        if (!response.ok) {
          return response.text().then(text => { // 捕获非2xx响应的文本
            throw new Error(`HTTP error! status: ${response.status}, text: ${text}`);
          });
        }
        return response.json();
      })
      .then(data => {
        console.log('Background: Fetch data parsed successfully:', data); // 成功解析数据日志
        sendResponse({ success: true, data: data });
      })
      .catch(error => {
        console.error('Background: Fetch request failed:', error.message); // Fetch失败日志
        sendResponse({ success: false, error: error.message });
      });
    return true; // 表示异步响应
  } else if (request.action === 'setAuthToken') {
    chrome.storage.local.set({ password_manager_token: request.token }, () => {
      console.log('Background: AuthToken set in storage.'); // 设置AuthToken日志
      sendResponse({ success: true });
    });
    return true;
  } else if (request.action === 'getAuthToken') {
    chrome.storage.local.get('password_manager_token', (result) => {
      console.log('Background: AuthToken retrieved from storage.'); // 获取AuthToken日志
      sendResponse({ token: result.password_manager_token || '' });
    });
    return true;
  } else if (request.action === 'showNotification') {
    // 简单的通知，Chrome 扩展可以直接使用 Notification API 或通过内容脚本处理
    // 为了与您的用户脚本保持一致，我们让内容脚本处理通知。
    sendResponse({ success: true });
    return false; // 不需要异步响应
  } else if (request.action === 'copyToClipboard') {
      try {
          // navigator.clipboard API 只能在安全上下文 (HTTPS) 或活动标签页的脚本中直接使用
          // 对于 Service Worker，clipboardWrite 权限允许它在用户手势下写入
          // 但为了兼容性，通常仍然会通过内容脚本发起或依赖用户操作
          // 这里假设在 Service Worker 中可以被触发
          navigator.clipboard.writeText(request.text).then(() => {
              console.log('Background: Copied to clipboard successfully.');
              sendResponse({ success: true });
          }).catch(err => {
              console.error('Background: Failed to copy to clipboard:', err.message);
              sendResponse({ success: false, error: err.message });
          });
      } catch (e) {
          console.error('Background: Error in clipboard copy:', e.message);
          sendResponse({ success: false, error: e.message });
      }
      return true;
  }
});

// 注册上下文菜单项 - 确保在安装时创建
chrome.runtime.onInstalled.addListener(() => {
  console.log('Background: runtime.onInstalled triggered, creating context menu.');
  chrome.contextMenus.create({
    id: "openPasswordManager",
    title: "🔐 打开密码管理器",
    // "action" context is available for MV3. If you want it on right-click on any element, use "all".
    // "action" means it appears when you right-click the extension icon in the toolbar.
    contexts: ["action"]
  });
});

// !!! 核心修正 !!!
// 将 chrome.contextMenus.onClicked.addListener 放置在顶层作用域，与上述监听器并列
// 确保在 Service Worker 启动时同步注册
chrome.contextMenus.onClicked.addListener((info, tab) => {
  console.log('Background: Context menu clicked:', info.menuItemId);
  if (info.menuItemId === "openPasswordManager") {
    // 确保这里的 URL 与您的 API_BASE 匹配，以便打开正确的密码管理器页面
    chrome.tabs.create({ url: "https://pass.pages.dev/" });
  }
});

// 或者，如果你想从内容脚本触发背景脚本的功能，可以使用 chrome.runtime.sendMessage
// 例如，内容脚本可以发送一个 'openManager' 消息，背景脚本监听并打开新标签页。