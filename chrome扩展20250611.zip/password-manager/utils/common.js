// 通用工具类
class PMCommon {
    // 检查元素是否可见
    static isElementVisible(element) {
        if (!element) return false;

        try {
            const rect = element.getBoundingClientRect();
            const style = window.getComputedStyle(element);

            return rect.width > 0 &&
                   rect.height > 0 &&
                   style.display !== 'none' &&
                   style.visibility !== 'hidden' &&
                   style.opacity !== '0' &&
                   !element.hidden;
        } catch (e) {
            return false;
        }
    }

    // HTML转义
    static escapeHtml(text) {
        if (typeof text !== 'string') {
            text = String(text);
        }
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // 显示通知
    static showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `pm-notification ${type}`;
        notification.textContent = message;

        document.body.appendChild(notification);

        setTimeout(() => notification.classList.add('show'), 100);

        notification.onclick = () => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        };

        setTimeout(() => {
            if(document.body.contains(notification)) {
               notification.classList.remove('show');
               setTimeout(() => {
                   if (document.body.contains(notification)) {
                       notification.remove()
                   }
               }, 300);
            }
        }, 4000);
    }

    // 复制到剪贴板
    static async copyToClipboard(text) {
        try {
            await navigator.clipboard.writeText(text);
            this.showNotification('📋 已复制到剪贴板', 'success');
            return true;
        } catch (error) {
            // 降级方案
            try {
                const textArea = document.createElement('textarea');
                textArea.value = text;
                textArea.style.position = 'fixed';
                textArea.style.left = '-999999px';
                textArea.style.top = '-999999px';
                document.body.appendChild(textArea);
                textArea.focus();
                textArea.select();

                const successful = document.execCommand('copy');
                document.body.removeChild(textArea);

                if (successful) {
                    this.showNotification('📋 已复制到剪贴板', 'success');
                    return true;
                } else {
                    throw new Error('Copy command failed');
                }
            } catch (fallbackError) {
                this.showNotification('📋 复制失败，请手动复制', 'warning');
                return false;
            }
        }
    }

    // 查找用户名字段
    static findAllUsernameFields() {
        const selectors = [
            'input[type="text"]',
            'input[type="email"]',
            'input[type="tel"]',
            'input:not([type])',
            'input[name*="user" i]',
            'input[name*="email" i]',
            'input[name*="login" i]',
            'input[name*="account" i]',
            'input[name*="username" i]',
            'input[id*="user" i]',
            'input[id*="email" i]',
            'input[id*="login" i]',
            'input[id*="account" i]',
            'input[id*="username" i]',
            'input[placeholder*="用户" i]',
            'input[placeholder*="邮箱" i]',
            'input[placeholder*="email" i]',
            'input[placeholder*="username" i]',
            'input[placeholder*="账号" i]',
            'input[placeholder*="手机" i]',
            'input[placeholder*="phone" i]',
            'input[autocomplete="username"]',
            'input[autocomplete="email"]'
        ];

        const fields = new Set();

        selectors.forEach(selector => {
            try {
                document.querySelectorAll(selector).forEach(field => {
                    if (field.type !== 'password' &&
                        field.type !== 'hidden' &&
                        field.type !== 'submit' &&
                        field.type !== 'button' &&
                        this.isElementVisible(field)) {
                        fields.add(field);
                    }
                });
            } catch (e) {
                console.warn(`选择器 ${selector} 失败:`, e);
            }
        });

        return Array.from(fields);
    }

    // 查找密码字段
    static findAllPasswordFields() {
        return Array.from(document.querySelectorAll('input[type="password"]'))
            .filter(field => this.isElementVisible(field));
    }

    // 触发输入事件
    static triggerInputEvents(field, value) {
        const events = [
            { type: 'focus', event: new FocusEvent('focus', { bubbles: true }) },
            { type: 'input', event: new InputEvent('input', { bubbles: true, data: value }) },
            { type: 'change', event: new Event('change', { bubbles: true }) },
            { type: 'keydown', event: new KeyboardEvent('keydown', { bubbles: true }) },
            { type: 'keyup', event: new KeyboardEvent('keyup', { bubbles: true }) }
        ];

        events.forEach(({ type, event }) => {
            try {
                field.dispatchEvent(event);
            } catch (e) {
                console.warn(`触发${type}事件失败:`, e);
            }
        });

        // React特殊处理
        try {
            if (field._valueTracker) {
                field._valueTracker.setValue('');
            }
        } catch (e) {
            console.warn('React特殊处理失败:', e);
        }
    }

    // 填充输入字段
    static fillInputField(field, value, fieldType) {
        if (!field || !value) {
            return false;
        }

        try {
            if (!this.isElementVisible(field) || field.disabled || field.readOnly) {
                return false;
            }

            field.focus();
            field.value = '';
            field.value = value;

            // 使用原生setter
            try {
                const descriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
                if (descriptor && descriptor.set) {
                    descriptor.set.call(field, value);
                }
            } catch (e) {
                console.warn('原生setter失败:', e);
            }

            this.triggerInputEvents(field, value);

            if (field.value === value) {
                // 视觉反馈
                field.style.backgroundColor = '#dcfce7';
                field.style.borderColor = '#10b981';
                setTimeout(() => {
                    field.style.backgroundColor = '';
                    field.style.borderColor = '';
                }, 2000);

                setTimeout(() => {
                    try {
                        field.blur();
                    } catch (e) {
                        console.warn('移除焦点失败:', e);
                    }
                }, 200);

                return true;
            }

            return false;
        } catch (error) {
            console.error(`填充${fieldType}字段异常:`, error);
            return false;
        }
    }
}

window.PMCommon = PMCommon;
