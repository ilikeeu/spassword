// 后台脚本
class PasswordManagerBackground {
    constructor() {
        this.cache = {
            pageInfo: new Map(),
            lastUpdate: new Map(),
            cacheTTL: 5 * 60 * 1000 // 5分钟缓存
        };
        this.init();
    }

    init() {
        // 扩展安装时的初始化
        chrome.runtime.onInstalled.addListener((details) => {
            if (details.reason === 'install') {
                this.onInstall();
            } else if (details.reason === 'update') {
                this.onUpdate(details.previousVersion);
            }
        });

        // 点击扩展图标时打开设置页面
        chrome.action.onClicked.addListener((tab) => {
            chrome.runtime.openOptionsPage();
        });

        // 监听来自content script的消息
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            this.handleMessage(request, sender, sendResponse);
            return true; // 保持消息通道开放
        });

        // 减少标签页监听频率 - 只在用户切换标签页时更新
        chrome.tabs.onActivated.addListener((activeInfo) => {
            // 延迟执行，避免频繁切换
            setTimeout(() => {
                this.onTabActivated(activeInfo.tabId);
            }, 1000);
        });

        // 移除自动的标签页更新监听，改为手动触发
        // chrome.tabs.onUpdated.addListener(...) 已移除
    }

    onInstall() {
        console.log('密码管理助手 Pro 已安装');
        
        // 获取默认API地址
        const defaultApiBase = chrome.runtime.getManifest().default_api_base;
        
        // 设置默认配置
        chrome.storage.sync.set({
            'pm_config': {
                AUTO_SAVE: true,
                AUTO_FILL: true,
                SHOW_NOTIFICATIONS: true,
                DETECT_PASSWORD_CHANGE: true,
                DEBUG_MODE: false
            },
            'pm_button_position': { bottom: 20, right: 20 },
            'pm_api_base': defaultApiBase
        });

        // 打开欢迎页面
        chrome.runtime.openOptionsPage();
    }

    onUpdate(previousVersion) {
        console.log(`密码管理助手 Pro 已更新: ${previousVersion} -> ${chrome.runtime.getManifest().version}`);
        
        // 显示更新通知
        chrome.notifications.create({
            type: 'basic',
            iconUrl: 'assets/icon48.png',
            title: '密码管理助手 Pro',
            message: '扩展已更新到最新版本！'
        });
    }

    // 检查缓存是否有效
    isCacheValid(tabId) {
        const lastUpdate = this.cache.lastUpdate.get(tabId);
        if (!lastUpdate) return false;
        return Date.now() - lastUpdate < this.cache.cacheTTL;
    }

    // 更新缓存
    updateCache(tabId, pageInfo) {
        this.cache.pageInfo.set(tabId, pageInfo);
        this.cache.lastUpdate.set(tabId, Date.now());
    }

    // 清理过期缓存
    cleanExpiredCache() {
        const now = Date.now();
        for (const [tabId, lastUpdate] of this.cache.lastUpdate.entries()) {
            if (now - lastUpdate > this.cache.cacheTTL) {
                this.cache.pageInfo.delete(tabId);
                this.cache.lastUpdate.delete(tabId);
            }
        }
    }

    async onTabActivated(tabId) {
        // 清理过期缓存
        this.cleanExpiredCache();

        // 检查缓存
        if (this.isCacheValid(tabId)) {
            const cachedInfo = this.cache.pageInfo.get(tabId);
            if (cachedInfo && cachedInfo.matchesCount > 0) {
                this.updateBadge(tabId, cachedInfo.matchesCount);
                return;
            }
        }

        // 只有在缓存无效时才发送消息
        try {
            const response = await chrome.tabs.sendMessage(tabId, { 
                action: 'getPageInfo',
                skipApiCall: true // 告诉content script跳过API调用
            });
            
            if (response) {
                this.updateCache(tabId, response);
                if (response.matchesCount > 0) {
                    this.updateBadge(tabId, response.matchesCount);
                } else {
                    this.clearBadge(tabId);
                }
            }
        } catch (error) {
            this.clearBadge(tabId);
        }
    }

    updateBadge(tabId, count) {
        chrome.action.setBadgeText({
            text: count > 9 ? '9+' : count.toString(),
            tabId: tabId
        });
        
        chrome.action.setBadgeBackgroundColor({
            color: count > 0 ? '#10b981' : '#6b7280',
            tabId: tabId
        });
    }

    clearBadge(tabId) {
        chrome.action.setBadgeText({
            text: '',
            tabId: tabId
        });
    }

    async handleMessage(request, sender, sendResponse) {
        try {
            switch (request.action) {
                case 'updateBadge':
                    if (sender.tab) {
                        this.updateBadge(sender.tab.id, request.count || 0);
                        // 更新缓存
                        this.updateCache(sender.tab.id, {
                            matchesCount: request.count || 0,
                            formsCount: request.formsCount || 0,
                            url: sender.tab.url,
                            title: sender.tab.title
                        });
                    }
                    sendResponse({ success: true });
                    break;

                case 'clearBadge':
                    if (sender.tab) {
                        this.clearBadge(sender.tab.id);
                        // 清除缓存
                        this.cache.pageInfo.delete(sender.tab.id);
                        this.cache.lastUpdate.delete(sender.tab.id);
                    }
                    sendResponse({ success: true });
                    break;

                case 'openPasswordManager':
                    const apiBase = await this.getApiBase();
                    chrome.tabs.create({ url: apiBase });
                    sendResponse({ success: true });
                    break;

                case 'openOptions':
                    chrome.runtime.openOptionsPage();
                    sendResponse({ success: true });
                    break;

                case 'getConfig':
                    const config = await chrome.storage.sync.get(['pm_config']);
                    sendResponse({ config: config.pm_config });
                    break;

                case 'setConfig':
                    await chrome.storage.sync.set({ 'pm_config': request.config });
                    sendResponse({ success: true });
                    break;

                case 'getApiBase':
                    const apiBase2 = await this.getApiBase();
                    sendResponse({ apiBase: apiBase2 });
                    break;

                case 'setApiBase':
                    await chrome.storage.sync.set({ 'pm_api_base': request.apiBase });
                    sendResponse({ success: true });
                    break;

                default:
                    sendResponse({ error: 'Unknown action' });
            }
        } catch (error) {
            console.error('Background message handling error:', error);
            sendResponse({ error: error.message });
        }
    }

    async getApiBase() {
        const result = await chrome.storage.sync.get(['pm_api_base']);
        const defaultApiBase = chrome.runtime.getManifest().default_api_base;
        return result.pm_api_base || defaultApiBase;
    }
}

// 启动后台脚本
new PasswordManagerBackground();
