// content.js
(function() {
    'use strict';

    // 配置
    const CONFIG = {
        API_BASE: 'https://pass.pages.dev', // 确保这个地址是正确的
        STORAGE_KEY: 'password_manager_token',
        AUTO_SAVE: true,
        AUTO_FILL: true,
        SHOW_NOTIFICATIONS: true,
        DETECT_PASSWORD_CHANGE: true
    };

    // 全局变量
    let authToken = '';
    let currentUser = null;
    let isAuthenticated = false;
    let detectedForms = [];
    let passwordManagerUI = null;
    let isPasswordManagerSite = false;
    let cachedMatches = [];
    let lastSubmittedData = null;
    let _pm_observer_timer = null; // 用于 MutationObserver 的防抖定时器

    // 在内容脚本加载时立即从 storage 中获取 authToken
    chrome.storage.local.get(CONFIG.STORAGE_KEY, (result) => {
        authToken = result[CONFIG.STORAGE_KEY] || '';
        console.log('🔐 content.js: authToken loaded on startup:', authToken ? 'exists' : 'empty');
        init(); // 获取 token 后初始化脚本
    });

    // ========== 核心工具函数 - 放在最前面以确保所有地方都能访问 ==========

    /**
     * 检查 DOM 元素是否在页面上可见。
     * @param {HTMLElement} element - 要检查的元素。
     * @returns {boolean} 如果元素可见则返回 true。
     */
    function isElementVisible(element) {
        if (!element) return false;

        try {
            const rect = element.getBoundingClientRect();
            const style = window.getComputedStyle(element);

            return rect.width > 0 &&
                   rect.height > 0 &&
                   style.display !== 'none' &&
                   style.visibility !== 'hidden' &&
                   style.opacity !== '0' &&
                   !element.hidden;
        } catch (e) {
            console.warn('content.js: Error checking element visibility:', e);
            return false;
        }
    }

    /**
     * 对 HTML 文本进行转义，防止 XSS 攻击。
     * @param {string} text - 原始文本。
     * @returns {string} 转义后的 HTML 字符串。
     */
    function escapeHtml(text) {
        if (typeof text !== 'string') {
            text = String(text);
        }
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    /**
     * 显示桌面通知。
     * @param {string} message - 通知内容。
     * @param {string} type - 通知类型 ('success', 'error', 'warning', 'info')。
     */
    function showNotification(message, type = 'success') {
        if (!CONFIG.SHOW_NOTIFICATIONS) return;

        const notification = document.createElement('div');
        notification.className = `pm-notification ${type}`;
        notification.textContent = message;

        document.body.appendChild(notification);

        setTimeout(() => notification.classList.add('show'), 100);

        notification.onclick = () => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        };

        // 4 秒后自动消失
        setTimeout(() => {
            if(document.body.contains(notification)) {
               notification.classList.remove('show');
               setTimeout(() => {
                   if (document.body.contains(notification)) {
                       notification.remove()
                   }
               }, 300);
            }
        }, 4000);
    }

    /**
     * 向背景脚本发送请求。
     * @param {string} url - 请求的相对 URL。
     * @param {Object} options - 请求选项（method, headers, body）。
     * @returns {Promise<Object>} API 响应数据。
     */
    function makeRequest(url, options = {}) {
        return new Promise((resolve, reject) => {
            console.log(`content.js: 向背景脚本发送请求: ${options.method || 'GET'} ${url}`);
            chrome.runtime.sendMessage({
                action: 'makeRequest',
                url: CONFIG.API_BASE + url,
                options: {
                    method: options.method || 'GET',
                    headers: options.headers || {},
                    body: options.body
                }
            }, (response) => {
                // 检查 chrome.runtime.lastError 以捕获消息发送本身的错误
                if (chrome.runtime.lastError) {
                    const errMsg = "content.js: Error sending message to background: " + chrome.runtime.lastError.message;
                    console.error(errMsg);
                    return reject(new Error(errMsg));
                }
                if (response && response.success) {
                    console.log('content.js: 背景脚本请求成功响应。');
                    resolve(response.data);
                } else {
                    const errMsg = response?.error || '请求失败';
                    console.error('content.js: 背景脚本请求失败响应:', errMsg);
                    reject(new Error(errMsg));
                }
            });
        });
    }

    /**
     * 显示复制成功状态的视觉反馈。
     */
    function showCopySuccess() {
        const tokenDisplay = document.querySelector('.pm-token-display');
        if (tokenDisplay) {
            tokenDisplay.style.background = '#10b981';
            tokenDisplay.style.borderColor = '#10b981';
            tokenDisplay.style.color = 'white';
            setTimeout(() => {
                tokenDisplay.style.background = '';
                tokenDisplay.style.borderColor = ''; // Corrected typo here, was 'token.style.borderColor'
                tokenDisplay.style.color = '';
            }, 2000);
        }
    }


    // ========== 辅助填充函数 - 放在核心填充函数之前 ==========

    /**
     * 触发输入字段的各种 DOM 事件，模拟用户输入。
     * @param {HTMLInputElement} field - 要触发事件的字段。
     * @param {string} value - 填充的值。
     */
    function triggerInputEvents(field, value) {
        console.log('🎭 content.js: 触发输入事件');

        const events = [
            { type: 'focus', event: new FocusEvent('focus', { bubbles: true }) },
            { type: 'input', event: new InputEvent('input', { bubbles: true, data: value }) },
            { type: 'change', event: new Event('change', { bubbles: true }) },
            { type: 'keydown', event: new KeyboardEvent('keydown', { bubbles: true }) },
            { type: 'keyup', event: new KeyboardEvent('keyup', { bubbles: true }) }
        ];

        events.forEach(({ type, event }) => {
            try {
                field.dispatchEvent(event);
                console.log(`✅ content.js: 触发${type}事件成功`);
            } catch (e) {
                console.warn(`❌ content.js: 触发${type}事件失败:`, e);
            }
        });

        // 针对 React 等框架的特殊处理
        try {
            if (field._valueTracker) {
                field._valueTracker.setValue(''); // 尝试重置 React 的 valueTracker
                console.log('🔧 content.js: React _valueTracker 已重置');
            }
        } catch (e) {
            console.warn('content.js: React特殊处理失败:', e);
        }
    }

    /**
     * 改进的字段填充函数。
     * @param {HTMLInputElement} field - 要填充的输入字段。
     * @param {string} value - 要填充的值。
     * @param {string} fieldType - 字段类型（例如 '用户名' 或 '密码'），用于日志。
     * @returns {boolean} 是否成功填充。
     */
    function fillInputField(field, value, fieldType) {
        if (!field || !value) {
            console.log(`❌ content.js: ${fieldType}字段或值为空`);
            return false;
        }

        try {
            if (!isElementVisible(field)) {
                console.log(`❌ content.js: ${fieldType}字段不可见:`, field);
                return false;
            }

            if (field.disabled) {
                console.log(`❌ content.js: ${fieldType}字段被禁用:`, field);
                return false;
            }

            if (field.readOnly) {
                console.log(`❌ content.js: ${fieldType}字段为只读:`, field);
                return false;
            }

            console.log(`🔄 content.js: 开始填充${fieldType}字段:`, field);

            // 清空并设置值
            field.value = '';
            field.value = value;

            // 尝试使用原生 setter (React/Vue 等框架可能需要)
            try {
                const descriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
                if (descriptor && descriptor.set) {
                    descriptor.set.call(field, value);
                    console.log(`🔧 content.js: ${fieldType}字段使用原生setter设置值`);
                }
            } catch (e) {
                console.log(`⚠️ content.js: ${fieldType}字段原生setter失败:`, e);
            }

            // 触发事件
            triggerInputEvents(field, value);

            // 验证值
            const finalValue = field.value;
            if (finalValue === value) {
                console.log(`✅ content.js: ${fieldType}字段值设置成功`);
                // 视觉反馈
                field.style.backgroundColor = '#dcfce7';
                field.style.borderColor = '#10b981';
                setTimeout(() => {
                    field.style.backgroundColor = '';
                    field.style.borderColor = '';
                }, 2000);
                return true;
            } else {
                console.log(`❌ content.js: ${fieldType}字段值设置失败，期望: ${value}, 实际: ${finalValue}`);
                return false;
            }

        } catch (error) {
            console.error(`❌ content.js: 填充${fieldType}字段时发生异常:`, error);
            return false;
        } finally {
            // 移除焦点
            setTimeout(() => {
                try {
                    field.blur();
                } catch (e) {
                    console.warn('content.js: 移除焦点失败:', e);
                }
            }, 200);
        }
    }

    /**
     * 查找页面上所有可能的用户名/邮箱/账号字段。
     * @returns {Array<HTMLInputElement>} 找到的用户名字段数组。
     */
    function findAllUsernameFields() {
        console.log('🔍 content.js: 开始查找用户名字段');

        const selectors = [
            'input[type="text"]',
            'input[type="email"]',
            'input[type="tel"]',
            'input:not([type])', // Fallback for inputs without a specific type
            'input[name*="user" i]',
            'input[name*="email" i]',
            'input[name*="login" i]',
            'input[name*="account" i]',
            'input[name*="username" i]',
            'input[id*="user" i]',
            'input[id*="email" i]',
            'input[id*="login" i]',
            'input[id*="account" i]',
            'input[id*="username" i]',
            'input[placeholder*="用户" i]',
            'input[placeholder*="邮箱" i]',
            'input[placeholder*="email" i]',
            'input[placeholder*="username" i]',
            'input[placeholder*="账号" i]',
            'input[placeholder*="手机" i]',
            'input[placeholder*="phone" i]',
            'input[autocomplete="username"]',
            'input[autocomplete="email"]'
        ];

        const fields = new Set();

        selectors.forEach(selector => {
            try {
                document.querySelectorAll(selector).forEach(field => {
                    // 过滤掉密码、隐藏、提交、按钮类型的字段，并确保可见
                    if (field.type !== 'password' &&
                        field.type !== 'hidden' &&
                        field.type !== 'submit' &&
                        field.type !== 'button' &&
                        isElementVisible(field)) {
                        fields.add(field);
                    }
                });
            } catch (e) {
                console.warn(`content.js: 选择器 ${selector} 失败:`, e);
            }
        });

        const fieldsArray = Array.from(fields);
        console.log(`🔍 content.js: 找到 ${fieldsArray.length} 个用户名字段`);
        return fieldsArray;
    }

    /**
     * 查找页面上所有密码字段。
     * @returns {Array<HTMLInputElement>} 找到的密码字段数组。
     */
    function findAllPasswordFields() {
        console.log('🔍 content.js: 开始查找密码字段');
        const fields = Array.from(document.querySelectorAll('input[type="password"]'))
            .filter(field => isElementVisible(field));

        console.log(`🔍 content.js: 找到 ${fields.length} 个密码字段`);
        return fields;
    }

    /**
     * 主要的密码填充函数。
     * @param {Object} passwordData - 包含 username 和 password 的对象。
     */
    function fillPassword(passwordData) {
        console.log('🔐 content.js: 开始填充密码流程:', passwordData);
        try {
            const { username, password } = passwordData;

            if (!username || !password) {
                console.error('❌ content.js: 用户名或密码为空');
                showNotification('❌ 用户名或密码为空', 'error');
                return;
            }

            console.log('🔐 content.js: 准备填充:', {
                username: username?.substring(0, 3) + '***',
                hasPassword: !!password
            });

            const usernameFields = findAllUsernameFields();
            const passwordFields = findAllPasswordFields();

            console.log('🔍 content.js: 找到字段:', {
                usernameFields: usernameFields.length,
                passwordFields: passwordFields.length
            });

            if (usernameFields.length === 0 && passwordFields.length === 0) {
                console.warn('⚠️ content.js: 未找到任何可填充的字段');
                showNotification('⚠️ 未找到可填充的字段', 'warning');

                const allInputs = document.querySelectorAll('input');
                console.log('🔍 content.js: 页面所有输入字段:', Array.from(allInputs).map(input => ({
                    type: input.type,
                    name: input.name,
                    id: input.id,
                    className: input.className,
                    placeholder: input.placeholder,
                    visible: isElementVisible(input),
                    disabled: input.disabled,
                    readonly: input.readOnly
                })));
                return;
            }

            let filledFields = 0;

            if (usernameFields.length > 0 && username) {
                console.log('🔄 content.js: 开始填充用户名字段');
                usernameFields.forEach((field, index) => {
                    try {
                        console.log(`🔄 content.js: 尝试填充用户名字段 ${index + 1}:`, {
                            tag: field.tagName,
                            type: field.type,
                            name: field.name,
                            id: field.id,
                            className: field.className
                        });

                        if (fillInputField(field, username, '用户名')) {
                            filledFields++;
                            console.log(`✅ content.js: 用户名字段 ${index + 1} 填充成功`);
                        } else {
                            console.log(`❌ content.js: 用户名字段 ${index + 1} 填充失败`);
                        }
                    } catch (error) {
                        console.error(`❌ content.js: 用户名字段 ${index + 1} 填充异常:`, error);
                    }
                });
            }

            if (passwordFields.length > 0 && password) {
                console.log('🔄 content.js: 开始填充密码字段');
                passwordFields.forEach((field, index) => {
                    try {
                        console.log(`🔄 content.js: 尝试填充密码字段 ${index + 1}:`, {
                            tag: field.tagName,
                            type: field.type,
                            name: field.name,
                            id: field.id,
                            className: field.className
                        });

                        if (fillInputField(field, password, '密码')) {
                            filledFields++;
                            console.log(`✅ content.js: 密码字段 ${index + 1} 填充成功`);
                        } else {
                            console.log(`❌ content.js: 密码字段 ${index + 1} 填充失败`);
                        }
                    } catch (error) {
                        console.error(`❌ content.js: 密码字段 ${index + 1} 填充异常:`, error);
                    }
                });
            }

            if (filledFields > 0) {
                showNotification(`🔐 已填充 ${filledFields} 个字段`, 'success');
                console.log(`✅ content.js: 填充完成，共填充 ${filledFields} 个字段`);
            } else {
                showNotification('⚠️ 填充失败，请检查页面字段', 'warning');
                console.warn('⚠️ content.js: 所有字段填充都失败了');
            }

            if (passwordManagerUI) {
                passwordManagerUI.remove();
                passwordManagerUI = null;
            }

        } catch (error) {
            console.error('❌ content.js: 填充密码时发生错误:', error);
            showNotification('❌ 填充密码失败', 'error');
        }
    }

    /**
     * 从密码项的按钮元素中获取数据并填充密码。
     * @param {HTMLElement} buttonElement - 点击的填充按钮元素。
     */
    function fillPasswordFromElement(buttonElement) {
        console.log('🔐 content.js: fillPasswordFromElement 被调用', buttonElement);
        try {
            const passwordItem = buttonElement.closest('.pm-password-item');
            if (!passwordItem) {
                console.error('❌ content.js: 找不到 .pm-password-item 元素');
                showNotification('❌ 填充失败：找不到密码项', 'error');
                return;
            }

            const matchDataStr = passwordItem.getAttribute('data-match');
            if (!matchDataStr) {
                console.error('❌ content.js: 找不到 data-match 属性');
                showNotification('❌ 填充失败：找不到密码数据', 'error');
                return;
            }

            const matchData = JSON.parse(matchDataStr);
            console.log('🔐 content.js: 解析密码数据成功:', matchData);

            fillPassword(matchData);
        } catch (error) {
            console.error('❌ content.js: fillPasswordFromElement 执行失败:', error);
            showNotification('❌ 填充失败', 'error');
        }
    }

    // ========== UI 渲染辅助函数 - 放在 UI 核心函数（如 createPasswordManagerUI）之前 ==========

    /**
     * 渲染密码匹配统计信息。
     * @param {Array<Object>} matches - 匹配到的密码数组。
     * @returns {string} HTML 字符串。
     */
    function renderMatchStats(matches) {
        const exactCount = matches.filter(m => m.matchType === 'exact').length;
        const subdomainCount = matches.filter(m => m.matchType === 'subdomain').length;
        const sitenameCount = matches.filter(m => m.matchType === 'sitename').length;

        return `
            <div class="pm-match-stats">
                <div class="pm-match-stat">
                    <div class="pm-match-type-icon exact"></div>
                    <span class="count">${exactCount}</span>
                    <span>精确</span>
                </div>
                <div class="pm-match-stat">
                    <div class="pm-match-type-icon subdomain"></div>
                    <span class="count">${subdomainCount}</span>
                    <span>子域</span>
                </div>
                <div class="pm-match-stat">
                    <div class="pm-match-type-icon sitename"></div>
                    <span class="count">${sitenameCount}</span>
                    <span>站名</span>
                </div>
            </div>
        `;
    }

    /**
     * 渲染令牌输入部分。
     * @returns {string} HTML 字符串。
     */
    function renderTokenInput() {
        return `
            <div style="margin-top: 16px; padding-top: 16px; border-top: 1px solid #e5e7eb;">
                <p style="font-size: 12px; color: #6b7280; margin-bottom: 8px;">或手动输入登录令牌：</p>
                <input type="text" id="tokenInput" class="pm-input" placeholder="粘贴登录令牌..." style="font-size: 11px;">
                <button class="pm-btn" data-action="set-token" style="margin-top: 4px;">
                    设置令牌
                </button>
            </div>
        `;
    }

    /**
     * 渲染密码列表。
     * @param {Array<Object>} matches - 匹配到的密码数组。
     * @returns {string} HTML 字符串。
     */
    function renderPasswordList(matches) {
        return matches.map((match, index) => {
            const matchTypeText = {
                'exact': '精确匹配',
                'subdomain': '子域匹配',
                'sitename': '站名匹配'
            };

            const matchTypeIcon = {
                'exact': '🎯',
                'subdomain': '🌐',
                'sitename': '🏷️'
            };

            const lastUsed = match.updatedAt ? new Date(match.updatedAt).toLocaleDateString() : '未知';
            const matchDataAttr = escapeHtml(JSON.stringify(match));

            return `
                <div class="pm-password-item ${match.matchType}-match" data-match='${matchDataAttr}'>
                    <div class="pm-password-item-header">
                        <div>
                            <div class="pm-password-item-title">${escapeHtml(match.siteName)}</div>
                            <div class="pm-password-item-username">
                                <span>👤</span>
                                <span>${escapeHtml(match.username)}</span>
                            </div>
                        </div>
                        <div class="pm-match-badge ${match.matchType}">
                            <span>${matchTypeIcon[match.matchType]}</span>
                            <span>${matchTypeText[match.matchType] || match.matchType}</span>
                        </div>
                    </div>

                    ${match.url ? `<div class="pm-password-item-url">🔗 ${escapeHtml(match.url)}</div>` : ''}

                    <div class="pm-password-item-actions">
                        <button class="pm-btn-fill">
                            ⚡ 立即填充
                        </button>
                        <button class="pm-btn-history" data-password-id="${match.id}" title="查看密码历史">
                            📜
                        </button>
                    </div>

                    <div class="pm-password-item-meta">
                        <span>最后使用: ${lastUsed}</span>
                        <span>匹配度: ${match.matchScore}%</span>
                    </div>
                </div>
            `;
        }).join('');
    }

    /**
     * 渲染匹配的密码列表。
     * @param {Array<Object>} matches - 匹配到的密码数组。
     * @returns {string} HTML 字符串。
     */
    function renderPasswordMatches(matches) {
        let content = '';

        // 添加匹配类型说明
        content += `
            <div class="pm-match-summary">
                <div class="pm-match-summary-title">🎯 匹配说明</div>
                <div class="pm-match-types">
                    <div class="pm-match-type">
                        <div class="pm-match-type-icon exact"></div>
                        <span>精确：域名完全相同</span>
                    </div>
                    <div class="pm-match-type">
                        <div class="pm-match-type-icon subdomain"></div>
                        <span>子域：子域名匹配</span>
                    </div>
                    <div class="pm-match-type">
                        <div class="pm-match-type-icon sitename"></div>
                        <span>站名：网站名称包含</span>
                    </div>
                </div>
            </div>
        `;

        if (matches.length === 1) {
            const match = matches[0];
            content += `
                <button class="pm-quick-fill" data-match='${escapeHtml(JSON.stringify(match))}'>
                    <span>⚡</span>
                    <span>快速填充：${escapeHtml(match.username)}</span>
                </button>
            `;
        } else {
            content += `
                <div style="margin-bottom: 16px;">
                    <h4 style="margin: 0 0 12px 0; color: #1f2937; font-size: 14px;">
                        🔐 选择要填充的账户 (${matches.length} 个)
                    </h4>
                </div>
            `;
        }

        content += renderPasswordList(matches);
        return content;
    }

    /**
     * 渲染没有匹配密码时的提示。
     * @returns {string} HTML 字符串。
     */
    function renderNoMatches() {
        return `
            <div class="pm-no-matches">
                <p>🔍 未找到匹配的账户</p>
                <p style="font-size: 12px; margin-top: 4px;">登录后将自动保存新账户</p>
            </div>
        `;
    }

    /**
     * 渲染检测到的表单信息。
     * @returns {string} HTML 字符串。
     */
    function renderDetectedForms() {
        if (detectedForms.length === 0 || isPasswordManagerSite) return '';

        return `
            <div class="pm-save-form">
                <h4 style="margin: 0 0 8px 0; color: #1f2937; font-size: 14px;">📝 检测到 ${detectedForms.length} 个登录表单</h4>
                <p style="color: #6b7280; font-size: 12px; margin-bottom: 8px;">登录后可自动保存账户信息</p>
                <button class="pm-btn" data-action="highlight-forms">高亮显示表单</button>
            </div>
        `;
    }

    // ========== 核心功能函数和逻辑 - 按照执行顺序和依赖关系放置 ==========

    /**
     * 检查当前网站是否为密码管理器本身的网站。
     * @returns {boolean} 如果是密码管理器网站则返回 true。
     */
    function checkPasswordManagerSite() {
        // 使用 CONFIG.API_BASE 的 hostname 进行判断，更具动态性
        try {
            const apiHostname = new URL(CONFIG.API_BASE).hostname;
            isPasswordManagerSite = window.location.hostname.includes(apiHostname) ||
                                     window.location.hostname.includes('localhost') ||
                                     window.location.hostname.includes('127.0.0.1');
        } catch (e) {
            console.error('content.js: Error parsing API_BASE URL:', e);
            isPasswordManagerSite = false; // 如果解析失败，默认为非管理器站点
        }
        console.log(`content.js: Site check for ${window.location.hostname}, isPasswordManagerSite: ${isPasswordManagerSite}`);
        return isPasswordManagerSite;
    }

    /**
     * 获取密码匹配。
     * @returns {Promise<Array<Object>>} 匹配的密码数据数组。
     */
    async function getPasswordMatches() {
        if (!isAuthenticated || isPasswordManagerSite) {
            console.log('content.js: 不满足获取密码匹配条件：isAuthenticated=' + isAuthenticated + ', isPasswordManagerSite=' + isPasswordManagerSite);
            return [];
        }
        try {
            console.log('content.js: 正在请求密码匹配数据...');
            const response = await makeRequest('/api/auto-fill', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + authToken
                },
                body: JSON.stringify({
                    url: window.location.href
                })
            });
            console.log('content.js: 密码匹配数据获取成功:', response.matches?.length || 0, '条');
            return response.matches || [];
        } catch (error) {
            console.error('content.js: 获取密码匹配失败:', error);
            showNotification('❌ 获取密码匹配失败', 'error'); // 新增通知
            return [];
        }
    }


    /**
     * 更新浮动按钮的样式和匹配数显示。
     * @param {Array<Object>} matches - 匹配到的密码数据。
     */
    function updateFloatingButton(matches) {
        const floatingBtn = document.querySelector('.pm-floating-btn');
        if (!floatingBtn) {
            console.warn('content.js: updateFloatingButton: 浮动按钮不存在。');
            return;
        }

        floatingBtn.classList.remove('has-matches', 'multiple-matches');
        const existingCount = floatingBtn.querySelector('.match-count');
        if (existingCount) existingCount.remove();

        if (matches.length > 0) {
            if (matches.length === 1) {
                floatingBtn.classList.add('has-matches');
                floatingBtn.title = `找到 1 个匹配的账户`;
            } else {
                floatingBtn.classList.add('multiple-matches');
                floatingBtn.title = `找到 ${matches.length} 个匹配的账户`;

                const countBadge = document.createElement('div');
                countBadge.className = 'match-count';
                countBadge.textContent = matches.length > 9 ? '9+' : matches.length;
                floatingBtn.appendChild(countBadge);
            }
            console.log(`content.js: 浮动按钮已更新，匹配数：${matches.length}`);
        } else {
            floatingBtn.title = '密码管理助手 Pro';
            console.log('content.js: 浮动按钮已更新，无匹配项。');
        }
    }

    /**
     * 验证用户认证状态。
     */
    async function verifyAuth() {
        console.log('content.js: 开始验证认证状态...');
        if (!authToken) {
            console.log('content.js: AuthToken 为空，无法验证。');
            isAuthenticated = false;
            currentUser = null;
            showNotification('🔒 密码管理助手未连接', 'warning');
            updateFloatingButton([]);
            return;
        }
        try {
            const response = await makeRequest('/api/auth/verify', {
                method: 'GET',
                headers: {
                    'Authorization': 'Bearer ' + authToken
                }
            });

            if (response.authenticated) {
                isAuthenticated = true;
                currentUser = response.user;
                console.log('✅ content.js: 认证成功。');
                if (!isPasswordManagerSite) {
                    showNotification('🔐 密码管理助手已连接', 'success');
                    // 延迟检查密码匹配，给页面加载时间
                    setTimeout(checkPasswordMatches, 1000);
                }
            } else {
                // 认证失败，清除 token
                authToken = '';
                chrome.storage.local.set({ [CONFIG.STORAGE_KEY]: '' });
                isAuthenticated = false;
                currentUser = null;
                console.warn('🔒 content.js: 认证失败或令牌无效。');
                showNotification('🔒 密码管理助手未连接或认证过期', 'warning');
                updateFloatingButton([]); // 清空按钮状态
            }
        } catch (error) {
            console.error('content.js: 验证失败:', error);
            isAuthenticated = false;
            currentUser = null;
            showNotification('❌ 密码管理助手连接失败', 'error');
            updateFloatingButton([]); // 清空按钮状态
        }
    }

    /**
     * 检查当前页面是否有匹配的密码。
     */
    async function checkPasswordMatches() {
        try {
            console.log('content.js: 开始检查密码匹配...');
            const matches = await getPasswordMatches();
            cachedMatches = matches;
            updateFloatingButton(matches);
            console.log(`content.js: 密码匹配检查完成，找到 ${matches.length} 个匹配项。`);
        } catch (error) {
            console.error('content.js: 检查密码匹配失败:', error);
        }
    }

    /**
     * 创建浮动按钮。
     */
    function createFloatingButton() {
        // 检查是否已经存在，如果存在则不创建
        if (document.querySelector('.pm-floating-btn')) {
            console.log('content.js: 浮动按钮已存在，跳过创建。');
            return;
        }
        console.log('content.js: 尝试创建浮动按钮...');
        const btn = document.createElement('button');
        btn.className = 'pm-floating-btn';
        btn.innerHTML = '🔐';
        btn.title = '密码管理助手 Pro';
        btn.onclick = togglePasswordManager;
        document.body.appendChild(btn);
        console.log('🔐 content.js: 浮动按钮已创建并添加到 body。');
    }

    /**
     * 确保浮动按钮存在于页面上，如果不存在则创建，如果被隐藏则尝试恢复可见。
     */
    function ensureFloatingButtonExists() {
        let floatingBtn = document.querySelector('.pm-floating-btn');
        if (!floatingBtn) {
            console.log('content.js: 浮动按钮不存在，正在尝试创建...');
            createFloatingButton();
            // 重新创建后，可能需要再次更新其匹配状态
            if (isAuthenticated && !isPasswordManagerSite) {
                updateFloatingButton(cachedMatches); // 使用缓存的匹配数据更新按钮状态
            }
        } else {
            console.log('content.js: 浮动按钮已存在，检查可见性...');
            // 如果按钮存在，但可能被隐藏或移出了可视区域，可以尝试重新定位或确保可见
            if (!isElementVisible(floatingBtn)) {
                console.log('content.js: 浮动按钮存在但不可见，尝试确保其可见性。');
                // 可以尝试重置其样式属性，如果它被其他 CSS 覆盖导致隐藏
                floatingBtn.style.setProperty('display', '', 'important'); // 强制清除，可能被 important 覆盖
                floatingBtn.style.setProperty('visibility', '', 'important');
                floatingBtn.style.setProperty('opacity', '', 'important');
                // 也可以强制将其重新附加到 body，确保其在 DOM 树中的位置
                document.body.appendChild(floatingBtn); // 重新附加以确保层级和位置
                console.log('content.js: 浮动按钮已尝试重新附加和恢复可见性。');
            } else {
                console.log('content.js: 浮动按钮存在且可见。');
            }
        }
    }


    /**
     * 切换密码管理器界面（显示/隐藏弹出框）。
     */
    function togglePasswordManager() {
        if (passwordManagerUI) {
            console.log('content.js: 关闭密码管理界面。');
            passwordManagerUI.remove();
            passwordManagerUI = null;
            return;
        }
        console.log('content.js: 打开密码管理界面。');
        createPasswordManagerUI();
    }

    /**
     * 创建密码管理器 UI 弹出框。
     */
    async function createPasswordManagerUI() {
        const popup = document.createElement('div');
        popup.className = 'pm-popup';

        if (!isAuthenticated) {
            popup.innerHTML = `
                <div class="pm-popup-header">
                    <div class="pm-popup-title">
                        <span>🔐</span>
                        <span>密码管理助手 Pro</span>
                    </div>
                </div>
                <div class="pm-popup-content">
                    <div class="pm-login-prompt">
                        <p>请先登录密码管理器</p>
                        <button class="pm-login-btn">前往登录</button>
                        ${renderTokenInput()}
                    </div>
                </div>
            `;
        } else {
            if (isPasswordManagerSite) {
                popup.innerHTML = `
                    <div class="pm-popup-header">
                        <div class="pm-popup-title">
                            <span>🔐</span>
                            <span>密码管理助手 Pro</span>
                        </div>
                    </div>
                    <div class="pm-popup-content">
                        <div style="text-align: center; margin-bottom: 16px;">
                            <p style="color: #10b981; font-weight: 600;">✅ 已连接到密码管理器</p>
                        </div>
                        <div>
                            <p style="font-size: 12px; color: #6b7280; margin-bottom: 8px;">当前登录令牌：</p>
                            <div class="pm-token-display">
                                ${authToken.substring(0, 20)}...
                            </div>
                        </div>
                        <button class="pm-btn" data-action="refresh-auth" style="margin-top: 8px;">
                            🔄 刷新连接状态
                        </button>
                        <button class="pm-btn pm-btn-secondary" data-action="logout" style="margin-top: 8px;">
                            🚪 退出登录
                        </button>
                    </div>
                `;
            } else {
                console.log('content.js: 获取匹配密码以渲染UI...');
                const matches = cachedMatches.length > 0 ? cachedMatches : await getPasswordMatches();
                console.log(`content.js: 渲染UI，找到 ${matches.length} 个匹配。`);
                popup.innerHTML = `
                    <div class="pm-popup-header">
                        <div class="pm-popup-title">
                            <span>🔐</span>
                            <span>密码管理助手 Pro</span>
                        </div>
                        ${matches.length > 0 ? renderMatchStats(matches) : ''}
                    </div>
                    <div class="pm-popup-content">
                        ${matches.length > 0 ? renderPasswordMatches(matches) : renderNoMatches()}
                        ${renderDetectedForms()}
                    </div>
                `;
            }
        }

        document.body.appendChild(popup);
        passwordManagerUI = popup;

        // 使用事件委托来处理所有点击事件
        popup.addEventListener('click', (e) => {
            const target = e.target;
            const fillButton = target.closest('.pm-btn-fill');
            const historyButton = target.closest('.pm-btn-history');
            const quickFillButton = target.closest('.pm-quick-fill');
            const loginBtn = target.closest('.pm-login-btn');
            const tokenDisplay = target.closest('.pm-token-display');
            const actionButton = target.closest('.pm-btn');

            if (fillButton) {
                e.preventDefault();
                fillPasswordFromElement(fillButton);
            } else if (historyButton) {
                e.preventDefault();
                const passwordId = historyButton.getAttribute('data-password-id');
                if (passwordId) {
                    viewPasswordHistory(passwordId);
                }
            } else if (quickFillButton) {
                e.preventDefault();
                const matchData = JSON.parse(quickFillButton.dataset.match);
                fillPassword(matchData);
            } else if (loginBtn) {
                 window.open(CONFIG.API_BASE, '_blank');
            } else if (tokenDisplay) {
                window.pmExtension.copyToken(authToken); // 调用暴露的函数
            } else if (actionButton) {
                const action = actionButton.dataset.action;
                if(action === 'refresh-auth') window.pmExtension.refreshAuth(); // 调用暴露的函数
                else if(action === 'set-token') window.pmExtension.setToken(); // 调用暴露的函数
                else if(action === 'highlight-forms') window.pmExtension.highlightForms(); // 调用暴露的函数
                else if(action === 'logout') window.pmExtension.logout(); // 调用暴露的函数
            }
        });

        setTimeout(() => popup.classList.add('show'), 10);

        // 监听外部点击以关闭弹出框
        document.addEventListener('click', function closePopup(e) {
            // 确保点击的不是弹出框内部，也不是浮动按钮
            if (passwordManagerUI && !passwordManagerUI.contains(e.target) && !e.target.closest('.pm-floating-btn')) {
                console.log('content.js: 检测到外部点击，关闭弹出框。');
                passwordManagerUI.remove();
                passwordManagerUI = null;
                document.removeEventListener('click', closePopup); // 移除监听器以防止内存泄漏
            }
        });
    }

    /**
     * 更新现有密码并保存历史记录。
     * @param {string} passwordId - 要更新的密码 ID。
     * @param {string} newPassword - 新密码。
     */
    async function updateExistingPassword(passwordId, newPassword) {
        console.log('🔄 content.js: updateExistingPassword 被调用', passwordId);
        try {
            await makeRequest(`/api/update-existing-password`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + authToken
                },
                body: JSON.stringify({
                    passwordId: passwordId,
                    newPassword: newPassword
                })
            });

            showNotification('✅ 密码已更新，历史记录已保存', 'success');
            setTimeout(checkPasswordMatches, 1000); // 刷新匹配项

            const prompt = document.querySelector('.pm-password-change-prompt');
            if (prompt) {
                prompt.remove(); // 移除密码变更提示
            }
        } catch (error) {
            console.error('content.js: 更新密码失败:', error);
            showNotification('❌ 更新密码失败', 'error');
        }
    }

    /**
     * 获取并显示密码历史记录。
     * @param {string} passwordId - 密码 ID。
     */
    async function viewPasswordHistory(passwordId) {
        try {
            const response = await makeRequest(`/api/passwords/${passwordId}/history`, {
                method: 'GET',
                headers: {
                    'Authorization': 'Bearer ' + authToken
                }
            });

            showPasswordHistoryModal(response.history, passwordId);
        } catch (error) {
            console.error('content.js: 获取密码历史失败:', error);
            showNotification('❌ 获取密码历史失败', 'error');
        }
    }

    /**
     * 显示密码历史模态框。
     * @param {Array<Object>} history - 密码历史记录数组。
     * @param {string} passwordId - 当前密码 ID。
     */
    function showPasswordHistoryModal(history, passwordId) {
        const modal = document.createElement('div');
        modal.className = 'pm-password-history-modal';
        modal.innerHTML = `
            <div class="pm-modal-overlay">
                <div class="pm-modal-content">
                    <div class="pm-modal-header">
                        <h3>📜 密码历史记录</h3>
                        <button type="button" class="pm-close-btn">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="pm-modal-body">
                        ${history.length === 0 ?
                            '<p class="pm-text-center">暂无历史记录</p>' :
                            history.map((entry, index) => `
                                <div class="pm-history-item">
                                    <div class="pm-history-header">
                                        <span class="pm-history-date">${new Date(entry.changedAt).toLocaleString()}</span>
                                        <button type="button" class="pm-btn pm-btn-success pm-btn-sm pm-btn-restore" data-password-id="${entry.passwordId || passwordId}" data-history-id="${entry.id}">
                                            🔄 恢复此密码
                                        </button>
                                    </div>
                                    <div class="pm-history-password">
                                        <label>密码：</label>
                                        <span class="pm-password-value" id="historyPwd${index}">••••••••</span>
                                        <button type="button" class="pm-btn pm-btn-sm pm-btn-secondary pm-btn-toggle-history-pwd" data-element-id="historyPwd${index}" data-password="${escapeHtml(entry.oldPassword)}">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </div>
                                </div>
                            `).join('')
                        }
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(modal);

        const closeModal = () => {
            modal.remove();
        };

        const toggleHistoryPassword = (button) => {
            const elementId = button.dataset.elementId;
            const password = button.dataset.password;
            const element = document.getElementById(elementId);
            const icon = button.querySelector('i');

            if (element && icon) {
                if (element.textContent === '••••••••') {
                    element.textContent = password;
                    icon.className = 'fas fa-eye-slash';
                } else {
                    element.textContent = '••••••••';
                    icon.className = 'fas fa-eye';
                }
            }
        };

        const restorePasswordHistory = async (button) => {
            const passwordIdToRestore = button.dataset.passwordId;
            const historyIdToRestore = button.dataset.historyId;

            if (!confirm('确定要恢复到这个历史密码吗？当前密码将被保存到历史记录中。')) {
                return;
            }

            try {
                await makeRequest('/api/passwords/restore', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + authToken
                    },
                    body: JSON.stringify({ passwordId: passwordIdToRestore, historyId: historyIdToRestore })
                });

                showNotification('✅ 密码已恢复到历史版本', 'success');
                closeModal();
                setTimeout(checkPasswordMatches, 1000); // 刷新匹配项
            } catch (error) {
                showNotification('❌ 恢复密码失败', 'error');
                console.error('content.js: 恢复密码失败:', error);
            }
        };

        // 事件委托监听
        modal.addEventListener('click', (e) => {
            const target = e.target;

            if (target.matches('.pm-modal-overlay') || target.closest('.pm-close-btn')) {
                if (!target.closest('.pm-modal-content') || target.closest('.pm-close-btn')) {
                    closeModal();
                    return;
                }
            }

            const toggleButton = target.closest('.pm-btn-toggle-history-pwd');
            if (toggleButton) {
                toggleHistoryPassword(toggleButton);
                return;
            }

            const restoreButton = target.closest('.pm-btn-restore');
            if (restoreButton) {
                restorePasswordHistory(restoreButton);
                return;
            }
        });
    }

    /**
     * 检测页面上的登录表单。
     */
    function detectLoginForms() {
        const forms = document.querySelectorAll('form');
        detectedForms = [];
        console.log(`content.js: detectLoginForms: 页面上找到 ${forms.length} 个表单。`);

        forms.forEach(form => {
            const usernameField = form.querySelector('input[type="text"], input[type="email"], input[name*="user"], input[name*="email"], input[name*="login"], input[id*="user"], input[id*="email"], input[id*="login"]');
            const passwordField = form.querySelector('input[type="password"]');

            if (usernameField && passwordField) {
                if (isElementVisible(usernameField) && isElementVisible(passwordField)) {
                    detectedForms.push(form);
                    console.log('content.js: detectLoginForms: 找到一个可见的登录表单。');

                    if (CONFIG.AUTO_SAVE && !isPasswordManagerSite) {
                        // 确保事件监听器只添加一次
                        if (!form._pm_listener_added) {
                            form.addEventListener('submit', handleFormSubmit);
                            form._pm_listener_added = true;
                            console.log('content.js: detectLoginForms: 为表单添加 submit 监听器。');
                        }
                    }
                } else {
                    console.log('content.js: detectLoginForms: 找到一个登录表单，但其字段不可见。');
                }
            }
        });

        if (detectedForms.length > 0 && !isPasswordManagerSite) {
            console.log(`🔍 content.js: 检测到 ${detectedForms.length} 个可用登录表单。`);
        } else if (detectedForms.length === 0 && !isPasswordManagerSite) {
            console.log('🔍 content.js: 未检测到可用登录表单。');
        }
    }

    /**
     * 处理表单提交事件，检测密码变更并提示保存。
     * @param {Event} e - 提交事件。
     */
    async function handleFormSubmit(e) {
        if (!isAuthenticated || isPasswordManagerSite || !CONFIG.AUTO_SAVE) {
            console.log('content.js: handleFormSubmit: 不满足处理条件。isAuthenticated=' + isAuthenticated + ', isPasswordManagerSite=' + isPasswordManagerSite + ', AUTO_SAVE=' + CONFIG.AUTO_SAVE);
            return;
        }

        const form = e.target;

        // 启发式检测：如果表单中有多个可见的密码字段，则判断为注册或修改密码表单，不执行自动保存
        const passwordFields = form.querySelectorAll('input[type="password"]');
        const visiblePasswordFields = Array.from(passwordFields).filter(field => isElementVisible(field));

        if (visiblePasswordFields.length > 1) {
            console.log('📝 content.js: 检测到注册/修改密码表单（存在多个密码框），本次提交将不自动保存密码。');
            return;
        }

        const usernameField = form.querySelector('input[type="text"], input[type="email"], input[name*="user"], input[name*="email"], input[name*="login"], input[id*="user"], input[id*="email"], input[id*="login"]');
        const passwordField = visiblePasswordFields[0];

        if (usernameField && passwordField && usernameField.value && passwordField.value) {
            const submitData = {
                url: window.location.href,
                username: usernameField.value,
                password: passwordField.value
            };
            console.log('content.js: handleFormSubmit: 捕获到表单提交数据。');
            // 记录提交数据，用于后续密码变更检测
            lastSubmittedData = submitData;

            // 延迟处理，给页面足够时间完成登录和重定向
            setTimeout(async () => {
                console.log('content.js: 延迟处理表单提交数据...');
                try {
                    const response = await makeRequest('/api/detect-login', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': 'Bearer ' + authToken
                        },
                        body: JSON.stringify(submitData)
                    });
                    console.log('content.js: API /api/detect-login 响应:', response);
                    if (response.exists && response.identical) {
                        showNotification('🔐 账户已存在且密码相同', 'info');
                    } else if (response.exists && response.passwordChanged && response.shouldUpdate && CONFIG.DETECT_PASSWORD_CHANGE) {
                        // 相同账号不同密码，显示更新提示
                        showPasswordChangePrompt(response.existing, submitData.password);
                    } else if (response.saved) {
                        showNotification('✅ 新账户已自动保存', 'success');
                        setTimeout(checkPasswordMatches, 1000); // 刷新匹配项
                    }
                } catch (error) {
                    console.error('content.js: 保存密码失败:', error);
                    // 可以根据错误类型显示更具体的通知
                    showNotification('❌ 自动保存密码失败', 'error');
                }
            }, 1000);
        } else {
            console.log('content.js: handleFormSubmit: 未能从表单中获取有效的用户名或密码。');
        }
    }

    /**
     * 显示密码变更提示。
     * @param {Object} existingPassword - 现有密码数据。
     * @param {string} newPassword - 新密码。
     */
    function showPasswordChangePrompt(existingPassword, newPassword) {
        const existingPrompt = document.querySelector('.pm-password-change-prompt');
        if (existingPrompt) {
            existingPrompt.remove(); // 移除旧的提示
        }
        console.log('content.js: 显示密码变更提示。');
        const prompt = document.createElement('div');
        prompt.className = 'pm-password-change-prompt';

        prompt.innerHTML = `
            <h4>🔄 检测到相同账号的密码变更</h4>
            <p>网站：${escapeHtml(existingPassword.siteName)}<br>
                用户：${escapeHtml(existingPassword.username)}</p>
            <p style="font-size: 11px;"><strong>注意：</strong>相同账号不会被保存为新账户，只能选择更新现有账户的密码。</p>
            <div class="pm-password-change-actions">
                <button class="pm-btn-update">
                    ✅ 更新密码
                </button>
                <button class="pm-btn-history-view">
                    📜 查看历史
                </button>
                <button class="pm-btn-ignore">
                    ❌ 忽略
                </button>
            </div>
        `;

        document.body.appendChild(prompt);

        // 为提示框添加事件监听
        prompt.addEventListener('click', (e) => {
            if (e.target.closest('.pm-btn-update')) {
                updateExistingPassword(existingPassword.id, newPassword);
            } else if (e.target.closest('.pm-btn-history-view')) {
                viewPasswordHistory(existingPassword.id);
                prompt.remove(); // 关闭提示框
            } else if (e.target.closest('.pm-btn-ignore')) {
                prompt.remove(); // 关闭提示框
            }
        });

        // 15 秒后自动消失
        setTimeout(() => {
            if (document.body.contains(prompt)) {
                console.log('content.js: 密码变更提示自动移除。');
                prompt.remove();
            }
        }, 15000);
    }

    /**
     * 监听 DOM 变化，重新检测表单和确保浮动按钮的存在。
     */
    function observeFormChanges() {
        const observer = new MutationObserver((mutations) => {
            let shouldRedetect = false;
            let shouldCheckFloatingButton = false;

            mutations.forEach((mutation) => {
                if (mutation.type === 'childList') {
                    // 只要有节点增减，就可能需要重新检查浮动按钮
                    if (mutation.addedNodes.length > 0 || mutation.removedNodes.length > 0) {
                        shouldCheckFloatingButton = true;
                    }

                    mutation.addedNodes.forEach((node) => {
                        if (node.nodeType === Node.ELEMENT_NODE) {
                            if (node.tagName === 'FORM' ||
                                node.querySelector && (node.querySelector('form') || node.querySelector('input[type="password"]'))) {
                                shouldRedetect = true;
                            }
                        }
                    });
                }
                // 也可以添加 attribute 监听，如果按钮可能因为样式属性变化而隐藏
                // if (mutation.type === 'attributes' && (mutation.attributeName === 'style' || mutation.attributeName === 'class')) {
                //     if (mutation.target.classList && mutation.target.classList.contains('pm-floating-btn')) {
                //         shouldCheckFloatingButton = true;
                //     }
                // }
            });

            if (shouldRedetect || shouldCheckFloatingButton) {
                // 使用防抖动，避免在短时间内频繁执行
                clearTimeout(_pm_observer_timer);
                _pm_observer_timer = setTimeout(() => {
                    console.log('content.js: DOM 变化检测到，执行重新检测和按钮检查。');
                    detectLoginForms();
                    if (isAuthenticated && !isPasswordManagerSite) {
                        checkPasswordMatches();
                    }
                    ensureFloatingButtonExists(); // 重新确保浮动按钮存在
                }, 500); // 500ms 防抖延迟
            }
        });

        observer.observe(document.body, {
            childList: true, // 监听子节点（元素）的添加或移除
            subtree: true,   // 监听所有后代节点
            // attributes: true // 如果您想监听元素属性变化（如 display: none），可以开启此项
        });
        console.log('content.js: MutationObserver 已启动。');
    }

    /**
     * 监听 URL 变化，主要用于单页应用 (SPA)。
     */
    let lastKnownUrl = window.location.href;
    function setupUrlChangeListener() {
        // 劫持 pushState 和 replaceState
        const originalPushState = history.pushState;
        history.pushState = function() {
            originalPushState.apply(this, arguments);
            window.dispatchEvent(new Event('pushstate'));
        };

        const originalReplaceState = history.replaceState;
        history.replaceState = function() {
            originalReplaceState.apply(this, arguments);
            window.dispatchEvent(new Event('replacestate'));
        };

        // 监听 popstate (浏览器前进/后退)，以及被劫持的 pushstate/replacestate 事件
        window.addEventListener('popstate', handleUrlChange);
        window.addEventListener('pushstate', handleUrlChange);
        window.addEventListener('replacestate', handleUrlChange);
        console.log('content.js: URL 变化监听器已设置。');
    }

    /**
     * 处理 URL 变化事件，重新初始化相关功能。
     */
    function handleUrlChange() {
        if (window.location.href !== lastKnownUrl) {
            console.log('content.js: URL 变化检测到:', window.location.href);
            lastKnownUrl = window.location.href;

            // 重新初始化所有可能受 URL 影响的功能
            setTimeout(() => {
                console.log('content.js: URL 变化后，重新检测表单和按钮。');
                detectLoginForms();
                if (isAuthenticated && !isPasswordManagerSite) {
                    checkPasswordMatches();
                }
                ensureFloatingButtonExists(); // 确保按钮存在
            }, 300); // 稍作延迟，给页面时间加载新内容
        }
    }

    /**
     * 监听密码管理器站点的登录状态变化。
     */
    function monitorPasswordManagerAuth() {
        console.log('content.js: 正在监听密码管理器站点登录状态...');
        // 通过定时检查 chrome.storage.local 中的 token 来同步状态
        setInterval(() => {
            chrome.storage.local.get(CONFIG.STORAGE_KEY, (result) => {
                const newToken = result[CONFIG.STORAGE_KEY];
                if (newToken && newToken !== authToken) {
                    authToken = newToken;
                    isAuthenticated = true;
                    showNotification('🔐 密码管理助手登录状态已同步', 'success');
                    console.log('content.js: 密码管理器登录令牌已更新并同步。');
                    // 如果弹出框已打开，重新渲染它
                    if (passwordManagerUI) {
                        passwordManagerUI.remove();
                        passwordManagerUI = null;
                        createPasswordManagerUI();
                    }
                } else if (!newToken && authToken) { // token 被清空了
                    authToken = '';
                    isAuthenticated = false;
                    showNotification('🔒 密码管理助手已退出登录', 'info');
                    console.log('content.js: 密码管理器令牌已清除。');
                    if (passwordManagerUI) {
                        passwordManagerUI.remove();
                        passwordManagerUI = null;
                        createPasswordManagerUI();
                    }
                }
            });
        }, 2000); // 每 2 秒检查一次
    }


    // ========== 初始化函数 - 最后调用 ==========

    /**
     * 初始化脚本。
     */
    async function init() {
        console.log('🔐 content.js: 密码管理助手 Pro Chrome 版已启动 (init)。');

        checkPasswordManagerSite();

        // 仅当 authToken 存在时才尝试验证
        if (authToken) {
            await verifyAuth(); // 验证认证状态
        } else {
            console.log('content.js: authToken 为空，跳过验证。');
            isAuthenticated = false; // 确保认证状态为 false
        }
        
        ensureFloatingButtonExists(); // 确保浮动按钮在初始化时就存在
        detectLoginForms(); // 检测登录表单
        observeFormChanges(); // 监听 DOM 变化
        setupUrlChangeListener(); // 监听 URL 变化，特别是对 SPA 有用

        // 如果是密码管理器网站，监听其登录状态变化
        if (isPasswordManagerSite) {
            monitorPasswordManagerAuth();
        } else if (isAuthenticated) {
            // 如果已认证且不在密码管理器网站，检查密码匹配
            checkPasswordMatches();
        } else {
            console.log('content.js: 未认证且不在密码管理器网站，不检查密码匹配。');
        }
    }

    // ========== window.pmExtension 暴露的函数 (放在最底部，因为它们只是一个接口，不影响内部定义顺序) ==========
    window.pmExtension = {
        fillPassword: fillPassword,

        setToken: function() {
            console.log('content.js: setToken function called.');
            // 确保 passwordManagerUI 存在且 tokenInput 在其中
            if (!passwordManagerUI) {
                showNotification('请先打开密码管理界面', 'warning');
                console.warn('content.js: Attempted to set token when passwordManagerUI is not open.');
                return;
            }
            // 确保在 passwordManagerUI 内部查找 tokenInput
            const tokenInput = passwordManagerUI.querySelector('#tokenInput');
            if (!tokenInput) {
                showNotification('令牌输入框不存在', 'error');
                console.error('content.js: Could not find #tokenInput inside passwordManagerUI.');
                return;
            }
            const token = tokenInput.value.trim();
            if (token) {
                authToken = token;
                // 使用回调函数来确认保存成功
                chrome.storage.local.set({ [CONFIG.STORAGE_KEY]: token }, () => {
                    if (chrome.runtime.lastError) {
                        console.error('content.js: Failed to save token to storage:', chrome.runtime.lastError.message);
                        showNotification('❌ 保存令牌失败', 'error');
                        return;
                    }
                    console.log('content.js: Auth token saved to local storage:', token.substring(0, 10) + '...');
                    verifyAuth().then(() => {
                        if (passwordManagerUI) {
                            passwordManagerUI.remove();
                            passwordManagerUI = null;
                        }
                        createPasswordManagerUI(); // 重新创建 UI 以反映新的认证状态
                    });
                });
            } else {
                showNotification('令牌不能为空', 'warning');
                console.warn('content.js: Attempted to set empty token.');
            }
        },

        copyToken: function(token) {
            console.log('content.js: copyToken function called.');
            chrome.runtime.sendMessage({ action: 'copyToClipboard', text: token }, (response) => {
                if (chrome.runtime.lastError) {
                    console.error('content.js: Error sending copyToClipboard message:', chrome.runtime.lastError.message);
                    showNotification('❌ 复制失败：扩展通信错误', 'error');
                    return;
                }
                if (response && response.success) {
                    showCopySuccess();
                    showNotification('📋 令牌已复制到剪贴板', 'success');
                } else {
                    console.error('content.js: Clipboard copy failed from background:', response?.error);
                    showNotification('📋 复制失败，请手动复制', 'warning');
                }
            });
        },

        refreshAuth: async function() {
            console.log('content.js: refreshAuth function called.');
            await verifyAuth();
            showNotification('🔄 连接状态已刷新', 'info');
            if (passwordManagerUI) {
                passwordManagerUI.remove();
                passwordManagerUI = null;
            }
            createPasswordManagerUI();
        },

        highlightForms: function() {
            console.log('content.js: highlightForms function called.');
            detectedForms.forEach(form => {
                const overlay = document.createElement('div');
                overlay.className = 'pm-form-overlay';

                const rect = form.getBoundingClientRect();
                overlay.style.top = (rect.top + window.scrollY) + 'px';
                overlay.style.left = (rect.left + window.scrollX) + 'px';
                overlay.style.width = rect.width + 'px';
                overlay.style.height = rect.height + 'px';

                document.body.appendChild(overlay);

                setTimeout(() => overlay.remove(), 3000);
            });

            showNotification('📍 登录表单已高亮显示', 'info');
        },

        togglePasswordChangeDetection: function() {
            CONFIG.DETECT_PASSWORD_CHANGE = !CONFIG.DETECT_PASSWORD_CHANGE;
            showNotification(`密码变更检测已${CONFIG.DETECT_PASSWORD_CHANGE ? '开启' : '关闭'}`, 'info');
        },
        showDebugInfo: function() {
            console.log('=== content.js: 密码管理助手 Pro 调试信息 ===');
            console.log('认证状态:', isAuthenticated);
            console.log('当前用户:', currentUser);
            console.log('检测到的表单:', detectedForms);
            console.log('缓存的匹配:', cachedMatches);
            console.log('页面URL:', window.location.href);
            console.log('最后提交数据:', lastSubmittedData);
            console.log('配置信息:', CONFIG);
            console.log('pmExtension 对象:', window.pmExtension);

            const allInputs = document.querySelectorAll('input');
            console.log('页面所有输入字段:', Array.from(allInputs).map(input => ({
                type: input.type,
                name: input.name,
                id: input.id,
                placeholder: input.placeholder,
                visible: isElementVisible(input)
            })));

            showNotification('🔍 调试信息已输出到控制台', 'info');
        },
        testFillFunction: function() {
            console.log('content.js: testFillFunction called.');
            const testData = {
                id: 'test',
                username: 'test@example.com',
                password: 'testpassword123'
            };
            fillPassword(testData);
        },
        reDetectForms: function() {
            console.log('content.js: reDetectForms called.');
            detectLoginForms();
            if (isAuthenticated && !isPasswordManagerSite) {
                checkPasswordMatches();
            }
            showNotification('🔍 重新检测完成', 'info');
        },
        logout: function() {
            console.log('content.js: logout called.');
            authToken = '';
            chrome.storage.local.set({ [CONFIG.STORAGE_KEY]: '' }, () => {
                if (chrome.runtime.lastError) {
                    console.error('content.js: Failed to clear token from storage:', chrome.runtime.lastError.message);
                }
                isAuthenticated = false;
                currentUser = null;
                cachedMatches = [];
                updateFloatingButton([]); // 清空按钮上的匹配数
                showNotification('👋 已退出登录', 'info');
                if (passwordManagerUI) {
                    passwordManagerUI.remove();
                    passwordManagerUI = null;
                }
                createPasswordManagerUI(); // 重新渲染 UI 以显示登录状态
            });
        }
    };

    // `init()` 会在 `authToken` 加载后被调用，所以不需要 `DOMContentLoaded` 监听。
})();