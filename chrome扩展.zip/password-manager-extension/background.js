// background.js (Service Worker)

// 监听来自内容脚本的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'makeRequest') {
    fetch(request.url, request.options)
      .then(response => {
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
      })
      .then(data => sendResponse({ success: true, data: data }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true; // 表示异步响应
  } else if (request.action === 'setAuthToken') {
    chrome.storage.local.set({ password_manager_token: request.token }, () => {
      sendResponse({ success: true });
    });
    return true;
  } else if (request.action === 'getAuthToken') {
    chrome.storage.local.get('password_manager_token', (result) => {
      sendResponse({ token: result.password_manager_token || '' });
    });
    return true;
  } else if (request.action === 'showNotification') {
    // 简单的通知，Chrome 扩展可以直接使用 Notification API 或通过内容脚本处理
    // 为了与您的用户脚本保持一致，我们让内容脚本处理通知。
    sendResponse({ success: true });
    return false; // 不需要异步响应
  } else if (request.action === 'copyToClipboard') {
      try {
          navigator.clipboard.writeText(request.text).then(() => {
              sendResponse({ success: true });
          }).catch(err => {
              sendResponse({ success: false, error: err.message });
          });
      } catch (e) {
          sendResponse({ success: false, error: e.message });
      }
      return true;
  }
});

// 处理扩展菜单命令 (仅适用于 Manifest V3，需要在 manifest.json 中声明 "commands" )
// 注意：Manifest V3 不再支持 GM_registerMenuCommand 的直接等效，
// 你需要创建一个弹出页或通过命令来触发这些功能。
// 这里我们将通过 chrome.commands API 来模拟一部分，或者在内容脚本中创建这些功能。
// 为了简化，用户脚本中的 GM_registerMenuCommand 对应的功能将通过内容脚本的 UI 或内部逻辑触发。

// 注册一个上下文菜单项（可选）
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "openPasswordManager",
    title: "🔐 打开密码管理器",
    contexts: ["action"] // 显示在扩展的 Action 菜单中
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "openPasswordManager") {
    chrome.tabs.create({ url: "https://spassword.pages.dev/" });
  }
});

// 或者，如果你想从内容脚本触发背景脚本的功能，可以使用 chrome.runtime.sendMessage
// 例如，内容脚本可以发送一个 'openManager' 消息，背景脚本监听并打开新标签页。