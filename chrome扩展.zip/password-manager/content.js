// 内容脚本主文件
class PasswordManagerContent {
    constructor() {
        this.authToken = '';
        this.currentUser = null;
        this.isAuthenticated = false;
        this.detectedForms = [];
        this.passwordManagerUI = null;
        this.isPasswordManagerSite = false;
        this.cachedMatches = [];
        this.lastSubmittedData = null;
        this.floatingButton = null;
        this.apiBase = '';
        this.config = {
            AUTO_SAVE: true,
            AUTO_FILL: true,
            SHOW_NOTIFICATIONS: true,
            DETECT_PASSWORD_CHANGE: true
        };

        // 预加载图标
        this.preloadIcon();
        this.init();
    }

    preloadIcon() {
        const img = new Image();
        img.src = 'https://cdn.mevrik.com/uploads/image6848833820236.png';
        img.onload = () => {
            console.log('🖼️ 图标预加载成功');
        };
        img.onerror = () => {
            console.warn('⚠️ 图标预加载失败，将使用备用图标');
        };
    }

    async init() {
        console.log('🔐 密码管理助手 Pro 已启动');

        // 加载API基础地址
        this.apiBase = await this.getApiBase();
        
        this.checkPasswordManagerSite();
        this.authToken = await PMStorage.get(PMAPI.STORAGE_KEY, '');

        if (this.authToken) {
            await this.verifyAuth();
        }

        this.detectLoginForms();
        this.updateButtonVisibility();
        this.observeFormChanges();

        if (this.isPasswordManagerSite) {
            this.monitorPasswordManagerAuth();
        } else if (this.isAuthenticated) {
            this.checkPasswordMatches();
        }

        // 监听来自popup的消息
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            this.handleMessage(request, sender, sendResponse);
            return true; // 保持消息通道开放
        });

        // 监听API地址变更
        chrome.storage.onChanged.addListener((changes, namespace) => {
            if (namespace === 'sync' && changes.pm_api_base) {
                this.apiBase = changes.pm_api_base.newValue;
                this.checkPasswordManagerSite();
                console.log('🔄 API地址已更新:', this.apiBase);
            }
        });
    }

    async getApiBase() {
        const result = await PMStorage.get('pm_api_base', null);
        if (result) {
            return result;
        }
        // 从manifest获取默认值
        const defaultApiBase = chrome.runtime.getManifest().default_api_base;
        return defaultApiBase;
    }

    checkPasswordManagerSite() {
        try {
            const currentHost = window.location.hostname;
            const apiHost = new URL(this.apiBase).hostname;
            
            this.isPasswordManagerSite = currentHost === apiHost ||
                                         currentHost.includes('localhost') ||
                                         currentHost.includes('127.0.0.1');
        } catch (error) {
            console.warn('检查密码管理器站点失败:', error);
            this.isPasswordManagerSite = false;
        }
        return this.isPasswordManagerSite;
    }

    async verifyAuth() {
        try {
            const response = await PMAPI.verifyAuth();
            
            if (response.authenticated) {
                this.isAuthenticated = true;
                this.currentUser = response.user;
                if (!this.isPasswordManagerSite) {
                    PMCommon.showNotification('🔐 密码管理助手已连接', 'success');
                    setTimeout(() => this.checkPasswordMatches(), 1000);
                }
            } else {
                this.authToken = '';
                await PMStorage.remove(PMAPI.STORAGE_KEY);
                this.isAuthenticated = false;
            }
        } catch (error) {
            console.error('验证失败:', error);
            this.isAuthenticated = false;
        }
    }

    async checkPasswordMatches() {
        try {
            const matches = await PMAPI.getPasswordMatches(window.location.href);
            this.cachedMatches = matches;
            this.updateFloatingButton(matches);
            
            // 通知background script更新badge
            chrome.runtime.sendMessage({
                action: 'updateBadge',
                count: matches.length
            });
        } catch (error) {
            console.error('检查密码匹配失败:', error);
        }
    }

    detectLoginForms() {
        const forms = document.querySelectorAll('form');
        this.detectedForms = [];

        forms.forEach(form => {
            const usernameField = form.querySelector('input[type="text"], input[type="email"], input[name*="user"], input[name*="email"], input[name*="login"], input[id*="user"], input[id*="email"], input[id*="login"]');
            const passwordField = form.querySelector('input[type="password"]');

            if (usernameField && passwordField) {
                if (PMCommon.isElementVisible(usernameField) && PMCommon.isElementVisible(passwordField)) {
                    this.detectedForms.push(form);

                    if (this.config.AUTO_SAVE && !this.isPasswordManagerSite) {
                        form.addEventListener('submit', (e) => this.handleFormSubmit(e));
                    }
                }
            }
        });

        console.log(`🔍 检测到 ${this.detectedForms.length} 个登录表单`);
        this.updateButtonVisibility();
    }

    updateButtonVisibility() {
        if (this.isPasswordManagerSite) {
            this.showFloatingButton();
            return;
        }

        if (this.detectedForms.length > 0) {
            this.showFloatingButton();
        } else {
            this.hideFloatingButton();
        }
    }

    showFloatingButton() {
        if (!this.floatingButton) {
            this.floatingButton = this.createFloatingButton();
        } else if (!document.body.contains(this.floatingButton)) {
            document.body.appendChild(this.floatingButton);
        }
        this.floatingButton.style.display = 'flex';
    }

    hideFloatingButton() {
        if (this.floatingButton && document.body.contains(this.floatingButton)) {
            this.floatingButton.style.display = 'none';
        }
    }

    createFloatingButton() {
        const btn = document.createElement('button');
        btn.className = 'pm-floating-btn';
        btn.title = '密码管理助手 Pro';

        // 从存储中恢复位置
        PMStorage.get('pm_button_position', { bottom: 20, right: 20 }).then(savedPosition => {
            btn.style.bottom = savedPosition.bottom + 'px';
            btn.style.right = savedPosition.right + 'px';
        });

        // 创建加载指示器
        const loadingIndicator = document.createElement('div');
        loadingIndicator.className = 'pm-loading-indicator';
        loadingIndicator.innerHTML = '⏳';
        btn.appendChild(loadingIndicator);

        // 创建图标
        const icon = document.createElement('img');
        icon.src = 'https://cdn.mevrik.com/uploads/image6848833820236.png';
        icon.className = 'pm-floating-btn-icon';
        icon.alt = 'Password Manager';
        icon.style.display = 'none'; // 初始隐藏

        // 图片加载成功
        icon.onload = function() {
            console.log('🖼️ 密码管理器图标加载成功');
            loadingIndicator.style.display = 'none';
            icon.style.display = 'block';
            btn.style.opacity = '1';
        };

        // 图片加载失败，使用备用图标
        icon.onerror = function() {
            console.error('❌ 密码管理器图标加载失败，使用备用图标');
            loadingIndicator.style.display = 'none';
            btn.classList.add('fallback-icon');
            btn.innerHTML = '🔐';
            btn.style.opacity = '1';
        };

        // 初始时设置透明，等待图片加载
        btn.style.opacity = '0';
        btn.appendChild(icon);

        // 添加拖拽功能
        this.addDragFunctionality(btn);

        // 点击事件
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.togglePasswordManager();
        });

        document.body.appendChild(btn);
        return btn;
    }

    addDragFunctionality(btn) {
        let isDragging = false;
        let dragOffset = { x: 0, y: 0 };
        let startTime = 0;

        const startDrag = (clientX, clientY) => {
            isDragging = true;
            startTime = Date.now();
            btn.classList.add('dragging');

            const rect = btn.getBoundingClientRect();
            dragOffset.x = clientX - rect.left;
            dragOffset.y = clientY - rect.top;

            btn.style.pointerEvents = 'none';
        };

        const updatePosition = (clientX, clientY) => {
            const newX = clientX - dragOffset.x;
            const newY = clientY - dragOffset.y;

            const windowWidth = window.innerWidth;
            const windowHeight = window.innerHeight;
            const btnWidth = btn.offsetWidth;
            const btnHeight = btn.offsetHeight;

            const left = Math.max(0, Math.min(newX, windowWidth - btnWidth));
            const top = Math.max(0, Math.min(newY, windowHeight - btnHeight));

            const bottom = windowHeight - top - btnHeight;
            const right = windowWidth - left - btnWidth;

            btn.style.bottom = bottom + 'px';
            btn.style.right = right + 'px';
            btn.style.left = 'auto';
            btn.style.top = 'auto';
        };

        const endDrag = () => {
            const dragDuration = Date.now() - startTime;

            isDragging = false;
            btn.classList.remove('dragging');

            const bottom = parseInt(btn.style.bottom);
            const right = parseInt(btn.style.right);
            PMStorage.set('pm_button_position', { bottom, right });

            setTimeout(() => {
                btn.style.pointerEvents = 'auto';
                if (dragDuration < 200) {
                    this.togglePasswordManager();
                }
            }, 100);
        };

        // 鼠标事件
        btn.addEventListener('mousedown', (e) => {
            e.preventDefault();
            startDrag(e.clientX, e.clientY);
        });

        document.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            e.preventDefault();
            updatePosition(e.clientX, e.clientY);
        });

        document.addEventListener('mouseup', () => {
            if (!isDragging) return;
            endDrag();
        });

        // 触摸事件
        btn.addEventListener('touchstart', (e) => {
            e.preventDefault();
            const touch = e.touches[0];
            startDrag(touch.clientX, touch.clientY);
        }, { passive: false });

        document.addEventListener('touchmove', (e) => {
            if (!isDragging) return;
            e.preventDefault();
            const touch = e.touches[0];
            updatePosition(touch.clientX, touch.clientY);
        }, { passive: false });

        document.addEventListener('touchend', () => {
            if (!isDragging) return;
            endDrag();
        });
    }

    updateFloatingButton(matches) {
        if (!this.floatingButton) return;

        this.floatingButton.classList.remove('has-matches', 'multiple-matches');
        const existingCount = this.floatingButton.querySelector('.match-count');
        if (existingCount) existingCount.remove();

        if (matches.length > 0) {
            if (matches.length === 1) {
                this.floatingButton.classList.add('has-matches');
                this.floatingButton.title = `找到 1 个匹配的账户`;
            } else {
                this.floatingButton.classList.add('multiple-matches');
                this.floatingButton.title = `找到 ${matches.length} 个匹配的账户`;

                const countBadge = document.createElement('div');
                countBadge.className = 'match-count';
                countBadge.textContent = matches.length > 9 ? '9+' : matches.length;
                this.floatingButton.appendChild(countBadge);
            }
        } else {
            this.floatingButton.title = '密码管理助手 Pro';
        }
    }

    togglePasswordManager() {
        if (this.passwordManagerUI) {
            this.passwordManagerUI.remove();
            this.passwordManagerUI = null;
            return;
        }

        this.createPasswordManagerUI();
    }

    async createPasswordManagerUI() {
        const popup = document.createElement('div');
        popup.className = 'pm-popup';

        if (!this.isAuthenticated) {
            popup.innerHTML = this.renderLoginPrompt();
        } else {
            if (this.isPasswordManagerSite) {
                popup.innerHTML = this.renderPasswordManagerSiteUI();
            } else {
                const matches = this.cachedMatches.length > 0 ? this.cachedMatches : await PMAPI.getPasswordMatches(window.location.href);
                popup.innerHTML = this.renderPasswordMatchesUI(matches);
            }
        }

        document.body.appendChild(popup);
        this.passwordManagerUI = popup;

        // 事件委托
        popup.addEventListener('click', (e) => this.handlePopupClick(e));

        setTimeout(() => popup.classList.add('show'), 10);

        // 点击外部关闭
        document.addEventListener('click', (e) => {
            if (this.passwordManagerUI && !this.passwordManagerUI.contains(e.target) && !e.target.closest('.pm-floating-btn')) {
                this.passwordManagerUI.remove();
                this.passwordManagerUI = null;
            }
        }, { once: true });
    }

    renderLoginPrompt() {
        return `
            <div class="pm-popup-header">
                <div class="pm-popup-title">
                    <span>🔐</span>
                    <span>密码管理助手 Pro</span>
                </div>
            </div>
            <div class="pm-popup-content">
                <div class="pm-login-prompt">
                    <p>请先登录密码管理器或设置登录令牌</p>
                    <button class="pm-login-btn" data-action="open-manager">前往登录</button>
                    <button class="pm-login-btn" data-action="open-settings" style="margin-top: 8px; background: #6b7280;">⚙️ 打开设置</button>
                    <div style="margin-top: 16px; padding-top: 16px; border-top: 1px solid #e5e7eb;">
                        <p style="font-size: 12px; color: #6b7280; margin-bottom: 8px;">当前系统地址：</p>
                        <p style="font-size: 11px; color: #3b82f6; margin-bottom: 8px; word-break: break-all;">${this.apiBase}</p>
                        <p style="font-size: 12px; color: #6b7280; margin-bottom: 8px;">或手动输入登录令牌：</p>
                        <input type="text" id="tokenInput" class="pm-input" placeholder="粘贴登录令牌..." style="font-size: 11px;">
                        <button class="pm-btn" data-action="set-token" style="margin-top: 4px;">
                            设置令牌
                        </button>
                    </div>
                </div>
            </div>
        `;
    }

    renderPasswordManagerSiteUI() {
        return `
            <div class="pm-popup-header">
                <div class="pm-popup-title">
                    <span>🔐</span>
                    <span>密码管理助手 Pro</span>
                </div>
            </div>
            <div class="pm-popup-content">
                <div style="text-align: center; margin-bottom: 16px;">
                    <p style="color: #10b981; font-weight: 600;">✅ 已连接到密码管理器</p>
                    <p style="font-size: 12px; color: #6b7280; margin-top: 4px;">系统地址：${this.apiBase}</p>
                </div>
                <div>
                    <p style="font-size: 12px; color: #6b7280; margin-bottom: 8px;">当前登录令牌：</p>
                    <div class="pm-token-display" data-action="copy-token">
                        ${this.authToken.substring(0, 20)}...
                    </div>
                </div>
                <div style="display: flex; gap: 8px;">
                    <button class="pm-btn" data-action="refresh-auth" style="margin-top: 8px; flex: 1;">
                        🔄 刷新连接
                    </button>
                    <button class="pm-btn" data-action="open-settings" style="margin-top: 8px; background: #6b7280; flex: 1;">
                        ⚙️ 设置
                    </button>
                </div>
            </div>
        `;
    }

    renderPasswordMatchesUI(matches) {
        let content = `
            <div class="pm-popup-header">
                <div class="pm-popup-title">
                    <span>🔐</span>
                    <span>密码管理助手 Pro</span>
                </div>
                ${matches.length > 0 ? this.renderMatchStats(matches) : ''}
            </div>
            <div class="pm-popup-content">
        `;

        if (matches.length > 0) {
            content += this.renderPasswordMatches(matches);
        } else {
            content += this.renderNoMatches();
        }

        content += this.renderDetectedForms();
        content += '</div>';

        return content;
    }

    renderMatchStats(matches) {
        const exactCount = matches.filter(m => m.matchType === 'exact').length;
        const subdomainCount = matches.filter(m => m.matchType === 'subdomain').length;
        const sitenameCount = matches.filter(m => m.matchType === 'sitename').length;

        return `
            <div class="pm-match-stats">
                <div class="pm-match-stat">
                    <div class="pm-match-type-icon exact"></div>
                    <span class="count">${exactCount}</span>
                    <span>精确</span>
                </div>
                <div class="pm-match-stat">
                    <div class="pm-match-type-icon subdomain"></div>
                    <span class="count">${subdomainCount}</span>
                    <span>子域</span>
                </div>
                <div class="pm-match-stat">
                    <div class="pm-match-type-icon sitename"></div>
                    <span class="count">${sitenameCount}</span>
                    <span>站名</span>
                </div>
            </div>
        `;
    }

    renderPasswordMatches(matches) {
        let content = `
            <div class="pm-match-summary">
                <div class="pm-match-summary-title">🎯 匹配说明</div>
                <div class="pm-match-types">
                    <div class="pm-match-type">
                        <div class="pm-match-type-icon exact"></div>
                        <span>精确：域名完全相同</span>
                    </div>
                    <div class="pm-match-type">
                        <div class="pm-match-type-icon subdomain"></div>
                        <span>子域：子域名匹配</span>
                    </div>
                    <div class="pm-match-type">
                        <div class="pm-match-type-icon sitename"></div>
                        <span>站名：网站名称包含</span>
                    </div>
                </div>
            </div>
        `;

        content += `
            <div style="margin-bottom: 16px;">
                <h4 style="margin: 0 0 12px 0; color: #1f2937; font-size: 14px;">
                    🔐 选择要填充的账户 (${matches.length} 个)
                </h4>
            </div>
        `;

        content += this.renderPasswordList(matches);
        return content;
    }

    renderPasswordList(matches) {
        return matches.map((match, index) => {
            const matchTypeText = {
                'exact': '精确匹配',
                'subdomain': '子域匹配',
                'sitename': '站名匹配'
            };

            const matchTypeIcon = {
                'exact': '🎯',
                'subdomain': '🌐',
                'sitename': '🏷️'
            };

            const lastUsed = match.updatedAt ? new Date(match.updatedAt).toLocaleDateString() : '未知';
            const matchDataAttr = PMCommon.escapeHtml(JSON.stringify(match));

            return `
                <div class="pm-password-item ${match.matchType}-match" data-match='${matchDataAttr}'>
                    <div class="pm-password-item-header">
                        <div>
                            <div class="pm-password-item-title">${PMCommon.escapeHtml(match.siteName)}</div>
                            <div class="pm-password-item-username">
                                <span>👤</span>
                                <span>${PMCommon.escapeHtml(match.username)}</span>
                            </div>
                        </div>
                        <div class="pm-match-badge ${match.matchType}">
                            <span>${matchTypeIcon[match.matchType]}</span>
                            <span>${matchTypeText[match.matchType] || match.matchType}</span>
                        </div>
                    </div>

                    ${match.url ? `<div class="pm-password-item-url">🔗 ${PMCommon.escapeHtml(match.url)}</div>` : ''}

                    <div class="pm-password-item-actions">
                        <button class="pm-btn-fill" data-action="fill-password">
                            ⚡ 立即填充
                        </button>
                        <button class="pm-btn-history" data-action="view-history" data-password-id="${match.id}" title="查看密码历史">
                            📜
                        </button>
                    </div>

                    <div class="pm-password-item-meta">
                        <span>最后使用: ${lastUsed}</span>
                        <span>匹配度: ${match.matchScore}%</span>
                    </div>
                </div>
            `;
        }).join('');
    }

    renderNoMatches() {
        return `
            <div class="pm-no-matches">
                <p>🔍 未找到匹配的账户</p>
                <p style="font-size: 12px; margin-top: 4px;">登录后将自动保存新账户</p>
                <p style="font-size: 11px; color: #6b7280; margin-top: 8px;">当前系统：${this.apiBase}</p>
                <button class="pm-btn" data-action="open-settings" style="margin-top: 12px; background: #6b7280;">
                    ⚙️ 打开设置
                </button>
            </div>
        `;
    }

    renderDetectedForms() {
        if (this.detectedForms.length === 0 || this.isPasswordManagerSite) return '';

        return `
            <div class="pm-save-form">
                <h4 style="margin: 0 0 8px 0; color: #1f2937; font-size: 14px;">📝 检测到 ${this.detectedForms.length} 个登录表单</h4>
                <p style="color: #6b7280; font-size: 12px; margin-bottom: 8px;">登录后可自动保存账户信息</p>
                <div style="display: flex; gap: 8px;">
                    <button class="pm-btn" data-action="highlight-forms" style="flex: 1;">高亮显示表单</button>
                    <button class="pm-btn" data-action="open-settings" style="background: #6b7280; flex: 1;">⚙️ 设置</button>
                </div>
            </div>
        `;
    }

    handlePopupClick(e) {
        const target = e.target;
        const action = target.dataset.action;

        if (!action) return;

        switch (action) {
            case 'fill-password':
                this.fillPasswordFromElement(target);
                break;
            case 'view-history':
                const passwordId = target.dataset.passwordId;
                if (passwordId) {
                    this.viewPasswordHistory(passwordId);
                }
                break;
            case 'open-manager':
                chrome.runtime.sendMessage({ action: 'openPasswordManager' });
                break;
            case 'open-settings':
                chrome.runtime.sendMessage({ action: 'openOptions' });
                break;
            case 'set-token':
                this.setToken();
                break;
            case 'copy-token':
                PMCommon.copyToClipboard(this.authToken);
                break;
            case 'refresh-auth':
                this.refreshAuth();
                break;
            case 'highlight-forms':
                this.highlightForms();
                break;
        }
    }

    fillPasswordFromElement(buttonElement) {
        try {
            const passwordItem = buttonElement.closest('.pm-password-item');
            if (!passwordItem) {
                PMCommon.showNotification('❌ 填充失败：找不到密码项', 'error');
                return;
            }

            const matchDataStr = passwordItem.getAttribute('data-match');
            if (!matchDataStr) {
                PMCommon.showNotification('❌ 填充失败：找不到密码数据', 'error');
                return;
            }

            const matchData = JSON.parse(matchDataStr);
            this.fillPassword(matchData);
        } catch (error) {
            console.error('fillPasswordFromElement 执行失败:', error);
            PMCommon.showNotification('❌ 填充失败', 'error');
        }
    }

    fillPassword(passwordData) {
        try {
            const { username, password } = passwordData;

            if (!username || !password) {
                PMCommon.showNotification('❌ 用户名或密码为空', 'error');
                return;
            }

            const usernameFields = PMCommon.findAllUsernameFields();
            const passwordFields = PMCommon.findAllPasswordFields();

            if (usernameFields.length === 0 && passwordFields.length === 0) {
                PMCommon.showNotification('⚠️ 未找到可填充的字段', 'warning');
                return;
            }

            let filledFields = 0;

            // 填充用户名字段
            if (usernameFields.length > 0 && username) {
                usernameFields.forEach((field, index) => {
                    if (PMCommon.fillInputField(field, username, '用户名')) {
                        filledFields++;
                    }
                });
            }

            // 填充密码字段
            if (passwordFields.length > 0 && password) {
                passwordFields.forEach((field, index) => {
                    if (PMCommon.fillInputField(field, password, '密码')) {
                        filledFields++;
                    }
                });
            }

            if (filledFields > 0) {
                PMCommon.showNotification(`🔐 已填充 ${filledFields} 个字段`, 'success');
            } else {
                PMCommon.showNotification('⚠️ 填充失败，请检查页面字段', 'warning');
            }

            // 关闭弹窗
            if (this.passwordManagerUI) {
                this.passwordManagerUI.remove();
                this.passwordManagerUI = null;
            }

        } catch (error) {
            console.error('填充密码时发生错误:', error);
            PMCommon.showNotification('❌ 填充密码失败', 'error');
        }
    }

    async setToken() {
        const tokenInput = document.getElementById('tokenInput');
        const token = tokenInput ? tokenInput.value.trim() : '';
        
        if (token) {
            this.authToken = token;
            await PMStorage.set(PMAPI.STORAGE_KEY, token);
            await this.verifyAuth();
            
            if (this.passwordManagerUI) {
                this.passwordManagerUI.remove();
                this.passwordManagerUI = null;
            }
            this.createPasswordManagerUI();
        }
    }

    async refreshAuth() {
        await this.verifyAuth();
        PMCommon.showNotification('🔄 连接状态已刷新', 'info');
        
        if (this.passwordManagerUI) {
            this.passwordManagerUI.remove();
            this.passwordManagerUI = null;
        }
        this.createPasswordManagerUI();
    }

    highlightForms() {
        this.detectedForms.forEach(form => {
            const overlay = document.createElement('div');
            overlay.className = 'pm-form-overlay';

            const rect = form.getBoundingClientRect();
            overlay.style.cssText = `
                position: fixed;
                top: ${rect.top + window.scrollY}px;
                left: ${rect.left + window.scrollX}px;
                width: ${rect.width}px;
                height: ${rect.height}px;
                background: rgba(99, 102, 241, 0.2);
                border: 2px solid #6366f1;
                border-radius: 8px;
                pointer-events: none;
                z-index: 9998;
            `;

            document.body.appendChild(overlay);
            setTimeout(() => overlay.remove(), 3000);
        });

        PMCommon.showNotification('📍 登录表单已高亮显示', 'info');
    }

    async viewPasswordHistory(passwordId) {
        try {
            const response = await PMAPI.getPasswordHistory(passwordId);
            this.showPasswordHistoryModal(response.history, passwordId);
        } catch (error) {
            console.error('获取密码历史失败:', error);
            PMCommon.showNotification('❌ 获取密码历史失败', 'error');
        }
    }

    showPasswordHistoryModal(history, passwordId) {
        const modal = document.createElement('div');
        modal.className = 'pm-password-history-modal';
        modal.innerHTML = `
            <div class="pm-modal-overlay">
                <div class="pm-modal-content">
                    <div class="pm-modal-header">
                        <h3>📜 密码历史记录</h3>
                        <div class="pm-modal-header-actions">
                            ${history.length > 0 ? `
                                <button type="button" class="pm-btn pm-btn-danger pm-btn-sm" data-action="delete-all-history" data-password-id="${passwordId}" title="删除所有历史记录">
                                    🗑️ 清空历史
                                </button>
                            ` : ''}
                            <button type="button" class="pm-close-btn" data-action="close-modal">
                                ✕
                            </button>
                        </div>
                    </div>
                    <div class="pm-modal-body">
                        ${history.length === 0 ?
                          '<p class="pm-text-center">暂无历史记录</p>' :
                          history.map((entry, index) => `
                            <div class="pm-history-item">
                                <div class="pm-history-header">
                                    <span class="pm-history-date">${new Date(entry.changedAt).toLocaleString()}</span>
                                    <div class="pm-history-actions">
                                        <button type="button" class="pm-btn pm-btn-success pm-btn-sm" data-action="restore-password" data-password-id="${entry.passwordId || passwordId}" data-history-id="${entry.id}" title="恢复此密码">
                                            🔄 恢复
                                        </button>
                                        <button type="button" class="pm-btn pm-btn-danger pm-btn-sm" data-action="delete-history" data-password-id="${entry.passwordId || passwordId}" data-history-id="${entry.id}" title="删除此历史记录">
                                            🗑️ 删除
                                        </button>
                                    </div>
                                </div>
                                <div class="pm-history-password">
                                    <label>密码：</label>
                                    <span class="pm-password-value" id="historyPwd${index}">••••••••</span>
                                    <button type="button" class="pm-btn pm-btn-sm pm-btn-secondary" data-action="toggle-password" data-element-id="historyPwd${index}" data-password="${PMCommon.escapeHtml(entry.oldPassword)}">
                                        👁️
                                    </button>
                                </div>
                            </div>
                          `).join('')
                        }
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(modal);

        // 事件委托
        modal.addEventListener('click', async (e) => {
            const target = e.target;
            const action = target.dataset.action;

            if (!action) return;

            switch (action) {
                case 'close-modal':
                    if (target.closest('.pm-close-btn') || target.classList.contains('pm-modal-overlay')) {
                        modal.remove();
                    }
                    break;
                case 'toggle-password':
                    this.toggleHistoryPassword(target);
                    break;
                case 'restore-password':
                    await this.restorePassword(target);
                    break;
                case 'delete-history':
                    await this.deleteHistoryEntry(target);
                    break;
                case 'delete-all-history':
                    await this.deleteAllHistory(target);
                    break;
            }
        });
    }

    toggleHistoryPassword(button) {
        const elementId = button.dataset.elementId;
        const password = button.dataset.password;
        const element = document.getElementById(elementId);

        if (element) {
            if (element.textContent === '••••••••') {
                element.textContent = password;
                button.textContent = '🙈';
            } else {
                element.textContent = '••••••••';
                button.textContent = '👁️';
            }
        }
    }

    async restorePassword(button) {
        const passwordId = button.dataset.passwordId;
        const historyId = button.dataset.historyId;

        if (!confirm('确定要恢复到这个历史密码吗？当前密码将被保存到历史记录中。')) {
            return;
        }

        try {
            await PMAPI.restorePassword(passwordId, historyId);
            PMCommon.showNotification('✅ 密码已恢复到历史版本', 'success');
            
            const modal = document.querySelector('.pm-password-history-modal');
            if (modal) modal.remove();
            
            setTimeout(() => this.checkPasswordMatches(), 1000);
        } catch (error) {
            PMCommon.showNotification('❌ 恢复密码失败', 'error');
            console.error('恢复密码失败:', error);
        }
    }

    async deleteHistoryEntry(button) {
        const passwordId = button.dataset.passwordId;
        const historyId = button.dataset.historyId;

        if (!confirm('确定要删除这条历史记录吗？')) {
            return;
        }

        try {
            const response = await PMAPI.deleteHistoryEntry(passwordId, historyId);
            if (response.success) {
                PMCommon.showNotification('🗑️ 历史记录已删除', 'success');
                this.viewPasswordHistory(passwordId);
            } else {
                throw new Error(response.error || '删除失败');
            }
        } catch (error) {
            console.error('删除历史记录失败:', error);
            PMCommon.showNotification('❌ 删除历史记录失败: ' + error.message, 'error');
        }
    }

    async deleteAllHistory(button) {
        const passwordId = button.dataset.passwordId;

        if (!confirm('确定要删除所有历史记录吗？此操作无法撤销。')) {
            return;
        }

        try {
            const response = await PMAPI.deleteHistoryEntry(passwordId, 'all');
            if (response.success) {
                PMCommon.showNotification('🗑️ ' + response.message, 'success');
                this.viewPasswordHistory(passwordId);
            } else {
                throw new Error(response.error || '删除失败');
            }
        } catch (error) {
            console.error('删除所有历史记录失败:', error);
            PMCommon.showNotification('❌ 删除所有历史记录失败: ' + error.message, 'error');
        }
    }

    async handleFormSubmit(e) {
        if (!this.isAuthenticated || this.isPasswordManagerSite) return;

        const form = e.target;
        const passwordFields = form.querySelectorAll('input[type="password"]');
        const visiblePasswordFields = Array.from(passwordFields).filter(field => PMCommon.isElementVisible(field));

        if (visiblePasswordFields.length > 1) {
            console.log('检测到注册/修改密码表单，本次提交将不自动保存密码。');
            return;
        }

        const usernameField = form.querySelector('input[type="text"], input[type="email"], input[name*="user"], input[name*="email"], input[name*="login"], input[id*="user"], input[id*="email"], input[id*="login"]');
        const passwordField = visiblePasswordFields[0];

        if (usernameField && passwordField && usernameField.value && passwordField.value) {
            const submitData = {
                url: window.location.href,
                username: usernameField.value,
                password: passwordField.value
            };

            this.lastSubmittedData = submitData;

            setTimeout(async () => {
                try {
                    const response = await PMAPI.detectLogin(submitData);

                    if (response.exists && response.identical) {
                        PMCommon.showNotification('🔐 账户已存在且密码相同', 'info');
                    } else if (response.exists && response.passwordChanged && response.shouldUpdate) {
                        this.showPasswordChangePrompt(response.existing, submitData.password);
                    } else if (response.saved) {
                        PMCommon.showNotification('✅ 新账户已自动保存', 'success');
                        setTimeout(() => this.checkPasswordMatches(), 1000);
                    }
                } catch (error) {
                    console.error('保存密码失败:', error);
                }
            }, 1000);
        }
    }

    showPasswordChangePrompt(existingPassword, newPassword) {
        const existingPrompt = document.querySelector('.pm-password-change-prompt');
        if (existingPrompt) {
            existingPrompt.remove();
        }

        const prompt = document.createElement('div');
        prompt.className = 'pm-password-change-prompt';

        prompt.innerHTML = `
            <h4>🔄 检测到相同账号的密码变更</h4>
            <p>网站：${PMCommon.escapeHtml(existingPassword.siteName)}<br>
               用户：${PMCommon.escapeHtml(existingPassword.username)}</p>
            <p style="font-size: 11px;"><strong>注意：</strong>相同账号不会被保存为新账户，只能选择更新现有账户的密码。</p>
            <div class="pm-password-change-actions">
                <button class="pm-btn-update" data-action="update-password" data-password-id="${existingPassword.id}" data-new-password="${newPassword}">
                    ✅ 更新密码
                </button>
                <button class="pm-btn-history-view" data-action="view-history" data-password-id="${existingPassword.id}">
                    📜 查看历史
                </button>
                <button class="pm-btn-ignore" data-action="ignore-change">
                    ❌ 忽略
                </button>
            </div>
        `;

        document.body.appendChild(prompt);

        prompt.addEventListener('click', async (e) => {
            const target = e.target;
            const action = target.dataset.action;

            switch (action) {
                case 'update-password':
                    await this.updateExistingPassword(target.dataset.passwordId, target.dataset.newPassword);
                    break;
                case 'view-history':
                    this.viewPasswordHistory(target.dataset.passwordId);
                    prompt.remove();
                    break;
                case 'ignore-change':
                    prompt.remove();
                    break;
            }
        });

        setTimeout(() => {
            if (document.body.contains(prompt)) {
                prompt.remove();
            }
        }, 15000);
    }

    async updateExistingPassword(passwordId, newPassword) {
        try {
            await PMAPI.updateExistingPassword(passwordId, newPassword);
            PMCommon.showNotification('✅ 密码已更新，历史记录已保存', 'success');
            setTimeout(() => this.checkPasswordMatches(), 1000);

            const prompt = document.querySelector('.pm-password-change-prompt');
            if (prompt) {
                prompt.remove();
            }
        } catch (error) {
            console.error('更新密码失败:', error);
            PMCommon.showNotification('❌ 更新密码失败', 'error');
        }
    }

    observeFormChanges() {
        const observer = new MutationObserver((mutations) => {
            let shouldRedetect = false;

            mutations.forEach((mutation) => {
                if (mutation.type === 'childList') {
                    mutation.addedNodes.forEach((node) => {
                        if (node.nodeType === Node.ELEMENT_NODE) {
                            if (node.tagName === 'FORM' ||
                                node.querySelector && (node.querySelector('form') || node.querySelector('input[type="password"]'))) {
                                shouldRedetect = true;
                            }
                        }
                    });
                }
            });

            if (shouldRedetect) {
                setTimeout(() => {
                    this.detectLoginForms();
                    if (this.isAuthenticated && !this.isPasswordManagerSite) {
                        this.checkPasswordMatches();
                    }
                }, 500);
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    monitorPasswordManagerAuth() {
        const originalSetItem = localStorage.setItem;
        localStorage.setItem = function(key, value) {
            if (key === 'authToken') {
                if (value && value !== this.authToken) {
                    this.authToken = value;
                    PMStorage.set(PMAPI.STORAGE_KEY, value);
                    this.isAuthenticated = true;
                    PMCommon.showNotification('🔐 已自动获取登录令牌', 'success');
                }
            }
            originalSetItem.apply(this, arguments);
        }.bind(this);

        setInterval(() => {
            const newToken = localStorage.getItem('authToken');
            if (newToken && newToken !== this.authToken) {
                this.authToken = newToken;
                PMStorage.set(PMAPI.STORAGE_KEY, newToken);
                this.isAuthenticated = true;
                PMCommon.showNotification('🔐 密码管理器登录状态已同步', 'success');
            }
        }, 2000);
    }

    handleMessage(request, sender, sendResponse) {
        switch (request.action) {
            case 'getPageInfo':
                sendResponse({
                    url: window.location.href,
                    title: document.title,
                    formsCount: this.detectedForms.length,
                    matchesCount: this.cachedMatches.length,
                    isAuthenticated: this.isAuthenticated
                });
                break;
            case 'fillPassword':
                if (request.passwordData) {
                    this.fillPassword(request.passwordData);
                    sendResponse({ success: true });
                }
                break;
            case 'refreshMatches':
                this.checkPasswordMatches().then(() => {
                    sendResponse({ success: true });
                });
                break;
            default:
                sendResponse({ error: 'Unknown action' });
        }
    }
}

// 启动扩展
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        new PasswordManagerContent();
    });
} else {
    new PasswordManagerContent();
}
