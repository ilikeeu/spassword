// 后台脚本
class PasswordManagerBackground {
    constructor() {
        this.init();
    }

    init() {
        // 扩展安装时的初始化
        chrome.runtime.onInstalled.addListener((details) => {
            if (details.reason === 'install') {
                this.onInstall();
            } else if (details.reason === 'update') {
                this.onUpdate(details.previousVersion);
            }
        });

        // 点击扩展图标时打开设置页面
        chrome.action.onClicked.addListener((tab) => {
            chrome.runtime.openOptionsPage();
        });

        // 监听来自content script的消息
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            this.handleMessage(request, sender, sendResponse);
            return true; // 保持消息通道开放
        });

        // 监听标签页更新
        chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
            if (changeInfo.status === 'complete' && tab.url) {
                this.onTabUpdated(tabId, tab);
            }
        });

        // 监听标签页激活
        chrome.tabs.onActivated.addListener((activeInfo) => {
            this.onTabActivated(activeInfo.tabId);
        });
    }

    onInstall() {
        console.log('密码管理助手 Pro 已安装');
        
        // 获取默认API地址
        const defaultApiBase = chrome.runtime.getManifest().default_api_base;
        
        // 设置默认配置
        chrome.storage.sync.set({
            'pm_config': {
                AUTO_SAVE: true,
                AUTO_FILL: true,
                SHOW_NOTIFICATIONS: true,
                DETECT_PASSWORD_CHANGE: true,
                DEBUG_MODE: false
            },
            'pm_button_position': { bottom: 20, right: 20 },
            'pm_api_base': defaultApiBase
        });

        // 打开欢迎页面
        chrome.runtime.openOptionsPage();
    }

    onUpdate(previousVersion) {
        console.log(`密码管理助手 Pro 已更新: ${previousVersion} -> ${chrome.runtime.getManifest().version}`);
        
        // 显示更新通知
        chrome.notifications.create({
            type: 'basic',
            iconUrl: 'assets/icon48.png',
            title: '密码管理助手 Pro',
            message: '扩展已更新到最新版本！'
        });
    }

    async onTabUpdated(tabId, tab) {
        // 检查是否是支持的页面
        if (tab.url && (tab.url.startsWith('http://') || tab.url.startsWith('https://'))) {
            try {
                // 获取页面信息
                const response = await chrome.tabs.sendMessage(tabId, { action: 'getPageInfo' });
                
                if (response && response.matchesCount > 0) {
                    this.updateBadge(tabId, response.matchesCount);
                } else {
                    this.clearBadge(tabId);
                }
            } catch (error) {
                // 页面可能还没准备好或不支持content script
                this.clearBadge(tabId);
            }
        } else {
            this.clearBadge(tabId);
        }
    }

    async onTabActivated(tabId) {
        try {
            const response = await chrome.tabs.sendMessage(tabId, { action: 'getPageInfo' });
            
            if (response && response.matchesCount > 0) {
                this.updateBadge(tabId, response.matchesCount);
            } else {
                this.clearBadge(tabId);
            }
        } catch (error) {
            this.clearBadge(tabId);
        }
    }

    updateBadge(tabId, count) {
        chrome.action.setBadgeText({
            text: count > 9 ? '9+' : count.toString(),
            tabId: tabId
        });
        
        chrome.action.setBadgeBackgroundColor({
            color: count > 0 ? '#10b981' : '#6b7280',
            tabId: tabId
        });
    }

    clearBadge(tabId) {
        chrome.action.setBadgeText({
            text: '',
            tabId: tabId
        });
    }

    async handleMessage(request, sender, sendResponse) {
        try {
            switch (request.action) {
                case 'updateBadge':
                    if (sender.tab) {
                        this.updateBadge(sender.tab.id, request.count || 0);
                    }
                    sendResponse({ success: true });
                    break;

                case 'clearBadge':
                    if (sender.tab) {
                        this.clearBadge(sender.tab.id);
                    }
                    sendResponse({ success: true });
                    break;

                case 'openPasswordManager':
                    const apiBase = await this.getApiBase();
                    chrome.tabs.create({ url: apiBase });
                    sendResponse({ success: true });
                    break;

                case 'openOptions':
                    chrome.runtime.openOptionsPage();
                    sendResponse({ success: true });
                    break;

                case 'getConfig':
                    const config = await chrome.storage.sync.get(['pm_config']);
                    sendResponse({ config: config.pm_config });
                    break;

                case 'setConfig':
                    await chrome.storage.sync.set({ 'pm_config': request.config });
                    sendResponse({ success: true });
                    break;

                case 'getApiBase':
                    const apiBase2 = await this.getApiBase();
                    sendResponse({ apiBase: apiBase2 });
                    break;

                case 'setApiBase':
                    await chrome.storage.sync.set({ 'pm_api_base': request.apiBase });
                    sendResponse({ success: true });
                    break;

                default:
                    sendResponse({ error: 'Unknown action' });
            }
        } catch (error) {
            console.error('Background message handling error:', error);
            sendResponse({ error: error.message });
        }
    }

    async getApiBase() {
        const result = await chrome.storage.sync.get(['pm_api_base']);
        const defaultApiBase = chrome.runtime.getManifest().default_api_base;
        return result.pm_api_base || defaultApiBase;
    }
}

// 启动后台脚本
new PasswordManagerBackground();
