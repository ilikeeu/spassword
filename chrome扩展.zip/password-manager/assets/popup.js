// Popup 脚本
class PasswordManagerPopup {
    constructor() {
        this.currentTab = null;
        this.isAuthenticated = false;
        this.pageInfo = null;
        this.apiBase = '';
        
        this.init();
    }

    async init() {
        await this.loadApiBase();
        await this.getCurrentTab();
        await this.checkAuthStatus();
        this.bindEvents();
        await this.loadPageInfo();
        this.hideLoading();
    }

    async loadApiBase() {
        try {
            const result = await chrome.storage.sync.get(['pm_api_base']);
            const defaultApiBase = chrome.runtime.getManifest().default_api_base;
            this.apiBase = result.pm_api_base || defaultApiBase;
        } catch (error) {
            console.error('加载API地址失败:', error);
            // 使用默认地址作为备用
            this.apiBase = chrome.runtime.getManifest().default_api_base;
        }
    }

    async getCurrentTab() {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            this.currentTab = tab;
        } catch (error) {
            console.error('获取当前标签页失败:', error);
        }
    }

    async checkAuthStatus() {
        try {
            const token = await chrome.storage.sync.get(['password_manager_token']);
            this.isAuthenticated = !!token.password_manager_token;
            
            if (this.isAuthenticated) {
                // 验证令牌有效性
                const response = await fetch(`${this.apiBase}/api/auth/verify`, {
                    headers: {
                        'Authorization': 'Bearer ' + token.password_manager_token
                    }
                });
                
                if (response.ok) {
                    const data = await response.json();
                    if (data.authenticated) {
                        this.showAuthenticatedView(data.user);
                    } else {
                        this.showUnauthenticatedView();
                    }
                } else {
                    this.showUnauthenticatedView();
                }
            } else {
                this.showUnauthenticatedView();
            }
        } catch (error) {
            console.error('检查认证状态失败:', error);
            this.showUnauthenticatedView();
        }
    }

    async loadPageInfo() {
        if (!this.currentTab || !this.currentTab.id) return;

        try {
            const response = await chrome.tabs.sendMessage(this.currentTab.id, {
                action: 'getPageInfo'
            });

            if (response) {
                this.pageInfo = response;
                this.updatePageInfo();
            }
        } catch (error) {
            console.error('获取页面信息失败:', error);
            this.updatePageInfo({
                url: this.currentTab.url,
                title: this.currentTab.title,
                formsCount: 0,
                matchesCount: 0
            });
        }
    }

    showAuthenticatedView(user) {
        document.getElementById('not-authenticated').style.display = 'none';
        document.getElementById('token-input-section').style.display = 'none';
        document.getElementById('authenticated').style.display = 'block';
        
        document.getElementById('user-name').textContent = user.email || user.username || '已登录用户';
    }

    showUnauthenticatedView() {
        document.getElementById('authenticated').style.display = 'none';
        document.getElementById('token-input-section').style.display = 'none';
        document.getElementById('not-authenticated').style.display = 'block';
    }

    showTokenInputView() {
        document.getElementById('not-authenticated').style.display = 'none';
        document.getElementById('authenticated').style.display = 'none';
        document.getElementById('token-input-section').style.display = 'block';
        
        // 聚焦到输入框
        setTimeout(() => {
            document.getElementById('token-input').focus();
        }, 100);
    }

    updatePageInfo(info = this.pageInfo) {
        if (!info) return;

        try {
            const domain = new URL(info.url).hostname;
            document.getElementById('current-page').textContent = domain;
        } catch (error) {
            document.getElementById('current-page').textContent = '未知域名';
        }
        
        document.getElementById('matches-count').textContent = info.matchesCount || 0;
        document.getElementById('forms-count').textContent = info.formsCount || 0;
    }

    hideLoading() {
        document.getElementById('loading').style.display = 'none';
    }

    bindEvents() {
        // 打开密码管理器
        document.getElementById('open-manager-btn').addEventListener('click', () => {
            chrome.tabs.create({ url: this.apiBase });
            window.close();
        });

        // 设置令牌
        document.getElementById('set-token-btn').addEventListener('click', () => {
            this.showTokenInputView();
        });

        // 保存令牌
        document.getElementById('save-token-btn').addEventListener('click', async () => {
            const token = document.getElementById('token-input').value.trim();
            if (token) {
                await this.saveToken(token);
            }
        });

        // 取消设置令牌
        document.getElementById('cancel-token-btn').addEventListener('click', () => {
            this.showUnauthenticatedView();
        });

        // 切换令牌可见性
        document.getElementById('toggle-token-visibility').addEventListener('click', () => {
            const input = document.getElementById('token-input');
            const button = document.getElementById('toggle-token-visibility');
            
            if (input.type === 'password') {
                input.type = 'text';
                button.textContent = '🙈';
            } else {
                input.type = 'password';
                button.textContent = '👁️';
            }
        });

        // 刷新匹配
        document.getElementById('refresh-btn').addEventListener('click', async () => {
            if (this.currentTab && this.currentTab.id) {
                try {
                    await chrome.tabs.sendMessage(this.currentTab.id, {
                        action: 'refreshMatches'
                    });
                    
                    // 重新加载页面信息
                    setTimeout(() => this.loadPageInfo(), 1000);
                } catch (error) {
                    console.error('刷新匹配失败:', error);
                }
            }
        });

        // 打开设置
        document.getElementById('options-btn').addEventListener('click', () => {
            chrome.runtime.openOptionsPage();
            window.close();
        });

        // 帮助链接
        document.getElementById('help-link').addEventListener('click', (e) => {
            e.preventDefault();
            chrome.tabs.create({ url: `${this.apiBase}/help` });
            window.close();
        });

        // 反馈链接
        document.getElementById('feedback-link').addEventListener('click', (e) => {
            e.preventDefault();
            chrome.tabs.create({ url: `${this.apiBase}/feedback` });
            window.close();
        });

        // 回车键保存令牌
        document.getElementById('token-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                document.getElementById('save-token-btn').click();
            }
        });
    }

    async saveToken(token) {
        try {
            await chrome.storage.sync.set({ 'password_manager_token': token });
            
            // 验证令牌
            const response = await fetch(`${this.apiBase}/api/auth/verify`, {
                headers: {
                    'Authorization': 'Bearer ' + token
                }
            });

            if (response.ok) {
                const data = await response.json();
                if (data.authenticated) {
                    this.isAuthenticated = true;
                    this.showAuthenticatedView(data.user);
                    await this.loadPageInfo();
                    
                    // 通知content script令牌已更新
                    if (this.currentTab && this.currentTab.id) {
                        try {
                            await chrome.tabs.sendMessage(this.currentTab.id, {
                                action: 'tokenUpdated',
                                token: token
                            });
                        } catch (error) {
                            // 忽略错误，可能页面还没准备好
                        }
                    }
                } else {
                    throw new Error('令牌验证失败');
                }
            } else {
                throw new Error('令牌无效');
            }
        } catch (error) {
            console.error('保存令牌失败:', error);
            alert('令牌保存失败，请检查令牌是否正确');
        }
    }
}

// 启动popup
document.addEventListener('DOMContentLoaded', () => {
    new PasswordManagerPopup();
});
