// API工具类
class PMAPI {
    static STORAGE_KEY = 'password_manager_token';
    static API_BASE_KEY = 'pm_api_base';

    static async getApiBase() {
        const result = await PMStorage.get(this.API_BASE_KEY, null);
        if (result) {
            return result;
        }
        // 从manifest获取默认值
        const defaultApiBase = chrome.runtime.getManifest().default_api_base;
        return defaultApiBase;
    }

    static async setApiBase(apiBase) {
        return await PMStorage.set(this.API_BASE_KEY, apiBase);
    }

    static async getToken() {
        return await PMStorage.get(this.STORAGE_KEY, '');
    }

    static async setToken(token) {
        return await PMStorage.set(this.STORAGE_KEY, token);
    }

    static async makeRequest(endpoint, options = {}) {
        const token = await this.getToken();
        const apiBase = await this.getApiBase();
        const url = apiBase + endpoint;
        
        const defaultOptions = {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                ...(token && { 'Authorization': 'Bearer ' + token })
            }
        };

        const finalOptions = { ...defaultOptions, ...options };

        try {
            const response = await fetch(url, finalOptions);
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.error || '请求失败');
            }
            
            return data;
        } catch (error) {
            console.error('API request failed:', error);
            throw error;
        }
    }

    static async verifyAuth() {
        try {
            const response = await this.makeRequest('/api/auth/verify');
            return {
                authenticated: response.authenticated,
                user: response.user
            };
        } catch (error) {
            return { authenticated: false, user: null };
        }
    }

    static async getPasswordMatches(url) {
        try {
            const response = await this.makeRequest('/api/auto-fill', {
                method: 'POST',
                body: JSON.stringify({ url })
            });
            return response.matches || [];
        } catch (error) {
            console.error('获取密码匹配失败:', error);
            return [];
        }
    }

    static async detectLogin(data) {
        return await this.makeRequest('/api/detect-login', {
            method: 'POST',
            body: JSON.stringify(data)
        });
    }

    static async updateExistingPassword(passwordId, newPassword) {
        return await this.makeRequest('/api/update-existing-password', {
            method: 'POST',
            body: JSON.stringify({ passwordId, newPassword })
        });
    }

    static async getPasswordHistory(passwordId) {
        return await this.makeRequest(`/api/passwords/${passwordId}/history`);
    }

    static async deleteHistoryEntry(passwordId, historyId) {
        return await this.makeRequest('/api/passwords/delete-history', {
            method: 'POST',
            body: JSON.stringify({ passwordId, historyId })
        });
    }

    static async restorePassword(passwordId, historyId) {
        return await this.makeRequest('/api/passwords/restore', {
            method: 'POST',
            body: JSON.stringify({ passwordId, historyId })
        });
    }
}

window.PMAPI = PMAPI;
