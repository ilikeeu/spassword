// Options 页面脚本
class PasswordManagerOptions {
    constructor() {
        this.config = {
            AUTO_SAVE: true,
            AUTO_FILL: true,
            SHOW_NOTIFICATIONS: true,
            DETECT_PASSWORD_CHANGE: true,
            DEBUG_MODE: false
        };
        this.apiBase = '';
        
        this.init();
    }

    async init() {
        await this.loadConfig();
        await this.loadApiBase();
        await this.checkAuthStatus();
        this.bindEvents();
        this.checkWelcomeMode();
    }

    checkWelcomeMode() {
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('welcome') === 'true') {
            document.getElementById('welcome-banner').style.display = 'block';
        }
    }

    async loadConfig() {
        try {
            const result = await chrome.storage.sync.get(['pm_config']);
            if (result.pm_config) {
                this.config = { ...this.config, ...result.pm_config };
            }
            this.updateConfigUI();
        } catch (error) {
            console.error('加载配置失败:', error);
        }
    }

    async loadApiBase() {
        try {
            const result = await chrome.storage.sync.get(['pm_api_base']);
            const defaultApiBase = chrome.runtime.getManifest().default_api_base;
            this.apiBase = result.pm_api_base || defaultApiBase;
            document.getElementById('api-base-input').value = this.apiBase;
        } catch (error) {
            console.error('加载API地址失败:', error);
        }
    }

    async saveConfig() {
        try {
            await chrome.storage.sync.set({ 'pm_config': this.config });
            this.showNotification('设置已保存', 'success');
        } catch (error) {
            console.error('保存配置失败:', error);
            this.showNotification('保存设置失败', 'error');
        }
    }

    async saveApiBase() {
        const newApiBase = document.getElementById('api-base-input').value.trim();
        
        if (!newApiBase) {
            this.showNotification('请输入有效的系统地址', 'error');
            return;
        }

        try {
            // 验证URL格式
            new URL(newApiBase);
            
            this.apiBase = newApiBase;
            await chrome.storage.sync.set({ 'pm_api_base': newApiBase });
            this.showNotification('✅ 系统地址已保存，建议重新获取登录令牌', 'success');
            
            // 重新检查认证状态
            setTimeout(() => this.checkAuthStatus(), 1000);
        } catch (error) {
            console.error('保存API地址失败:', error);
            this.showNotification('请输入有效的URL地址', 'error');
        }
    }

    updateConfigUI() {
        document.getElementById('auto-save-switch').checked = this.config.AUTO_SAVE;
        document.getElementById('auto-fill-switch').checked = this.config.AUTO_FILL;
        document.getElementById('show-notifications-switch').checked = this.config.SHOW_NOTIFICATIONS;
        document.getElementById('detect-change-switch').checked = this.config.DETECT_PASSWORD_CHANGE;
        document.getElementById('debug-mode-switch').checked = this.config.DEBUG_MODE;
    }

    async checkAuthStatus() {
        try {
            const result = await chrome.storage.sync.get(['password_manager_token']);
            const token = result.password_manager_token;
            
            if (token) {
                // 验证令牌
                const response = await fetch(`${this.apiBase}/api/auth/verify`, {
                    headers: {
                        'Authorization': 'Bearer ' + token
                    }
                });

                if (response.ok) {
                    const data = await response.json();
                    if (data.authenticated) {
                        this.updateAuthStatus(true, data.user);
                        return;
                    }
                }
            }
            
            this.updateAuthStatus(false);
        } catch (error) {
            console.error('检查认证状态失败:', error);
            this.updateAuthStatus(false);
        }
    }

    updateAuthStatus(isAuthenticated, user = null) {
        const statusIndicator = document.querySelector('.status-indicator');
        const statusText = document.querySelector('.status-text');
        
        if (isAuthenticated) {
            statusIndicator.className = 'status-indicator connected';
            statusText.textContent = `已连接 - ${user?.email || user?.username || '已登录用户'}`;
        } else {
            statusIndicator.className = 'status-indicator disconnected';
            statusText.textContent = '未连接';
        }
    }

    bindEvents() {
        // 欢迎横幅
        document.getElementById('start-setup-btn').addEventListener('click', () => {
            document.getElementById('welcome-banner').style.display = 'none';
            document.getElementById('api-base-input').focus();
        });

        // API地址设置
        document.getElementById('save-api-base-btn').addEventListener('click', () => {
            this.saveApiBase();
        });

        document.getElementById('reset-api-base-btn').addEventListener('click', () => {
            const defaultApiBase = chrome.runtime.getManifest().default_api_base;
            document.getElementById('api-base-input').value = defaultApiBase;
        });

        // 认证相关
        document.getElementById('refresh-auth-btn').addEventListener('click', () => {
            this.checkAuthStatus();
        });

        document.getElementById('save-token-btn').addEventListener('click', () => {
            this.saveToken();
        });

        document.getElementById('toggle-token-btn').addEventListener('click', () => {
            this.toggleTokenVisibility();
        });

        document.getElementById('get-token-btn').addEventListener('click', () => {
            chrome.tabs.create({ url: this.apiBase });
        });

        document.getElementById('clear-token-btn').addEventListener('click', () => {
            this.clearToken();
        });

        // 功能设置
        document.getElementById('auto-save-switch').addEventListener('change', (e) => {
            this.config.AUTO_SAVE = e.target.checked;
            this.saveConfig();
        });

        document.getElementById('auto-fill-switch').addEventListener('change', (e) => {
            this.config.AUTO_FILL = e.target.checked;
            this.saveConfig();
        });

        document.getElementById('show-notifications-switch').addEventListener('change', (e) => {
            this.config.SHOW_NOTIFICATIONS = e.target.checked;
            this.saveConfig();
        });

        document.getElementById('detect-change-switch').addEventListener('change', (e) => {
            this.config.DETECT_PASSWORD_CHANGE = e.target.checked;
            this.saveConfig();
        });

        document.getElementById('debug-mode-switch').addEventListener('change', (e) => {
            this.config.DEBUG_MODE = e.target.checked;
            this.saveConfig();
        });

        // 界面设置
        document.getElementById('reset-position-btn').addEventListener('click', () => {
            this.resetButtonPosition();
        });

        // 数据管理
        document.getElementById('export-data-btn').addEventListener('click', () => {
            this.exportData();
        });

        document.getElementById('import-data-btn').addEventListener('click', () => {
            document.getElementById('import-file-input').click();
        });

        document.getElementById('import-file-input').addEventListener('change', (e) => {
            this.importData(e.target.files[0]);
        });

        document.getElementById('clear-data-btn').addEventListener('click', () => {
            this.clearAllData();
        });

        // 帮助链接
        document.getElementById('help-link').addEventListener('click', (e) => {
            e.preventDefault();
            chrome.tabs.create({ url: `${this.apiBase}/help` });
        });

        document.getElementById('faq-link').addEventListener('click', (e) => {
            e.preventDefault();
            chrome.tabs.create({ url: `${this.apiBase}/faq` });
        });

        document.getElementById('feedback-link').addEventListener('click', (e) => {
            e.preventDefault();
            chrome.tabs.create({ url: `${this.apiBase}/feedback` });
        });

        document.getElementById('privacy-link').addEventListener('click', (e) => {
            e.preventDefault();
            chrome.tabs.create({ url: `${this.apiBase}/privacy` });
        });

        // 回车键保存
        document.getElementById('token-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.saveToken();
            }
        });

        document.getElementById('api-base-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.saveApiBase();
            }
        });
    }

    async saveToken() {
        const token = document.getElementById('token-input').value.trim();
        
        if (!token) {
            this.showNotification('请输入有效的令牌', 'error');
            return;
        }

        try {
            // 验证令牌
            const response = await fetch(`${this.apiBase}/api/auth/verify`, {
                headers: {
                    'Authorization': 'Bearer ' + token
                }
            });

            if (response.ok) {
                const data = await response.json();
                if (data.authenticated) {
                    await chrome.storage.sync.set({ 'password_manager_token': token });
                    this.updateAuthStatus(true, data.user);
                    this.showNotification('✅ 令牌保存成功', 'success');
                    document.getElementById('token-input').value = '';
                } else {
                    throw new Error('令牌验证失败');
                }
            } else {
                throw new Error('令牌无效');
            }
        } catch (error) {
            console.error('保存令牌失败:', error);
            this.showNotification('❌ 令牌保存失败，请检查令牌是否正确', 'error');
        }
    }

    toggleTokenVisibility() {
        const input = document.getElementById('token-input');
        const button = document.getElementById('toggle-token-btn');
        
        if (input.type === 'password') {
            input.type = 'text';
            button.textContent = '🙈';
        } else {
            input.type = 'password';
            button.textContent = '👁️';
        }
    }

    async clearToken() {
        if (!confirm('确定要清除登录令牌吗？这将退出登录状态。')) {
            return;
        }

        try {
            await chrome.storage.sync.remove(['password_manager_token']);
            this.updateAuthStatus(false);
            this.showNotification('令牌已清除', 'info');
        } catch (error) {
            console.error('清除令牌失败:', error);
            this.showNotification('清除令牌失败', 'error');
        }
    }

    async resetButtonPosition() {
        try {
            await chrome.storage.sync.set({ 'pm_button_position': { bottom: 20, right: 20 } });
            this.showNotification('按钮位置已重置', 'success');
        } catch (error) {
            console.error('重置按钮位置失败:', error);
            this.showNotification('重置失败', 'error');
        }
    }

    async exportData() {
        try {
            const data = await chrome.storage.sync.get();
            const exportData = {
                version: '2.1.7',
                timestamp: new Date().toISOString(),
                data: data
            };

            const blob = new Blob([JSON.stringify(exportData, null, 2)], {
                type: 'application/json'
            });

            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `password-manager-backup-${new Date().toISOString().split('T')[0]}.json`;
            a.click();
            URL.revokeObjectURL(url);

            this.showNotification('数据导出成功', 'success');
        } catch (error) {
            console.error('导出数据失败:', error);
            this.showNotification('导出数据失败', 'error');
        }
    }

    async importData(file) {
        if (!file) return;

        try {
            const text = await file.text();
            const importData = JSON.parse(text);

            if (!importData.data) {
                throw new Error('无效的备份文件格式');
            }

            if (!confirm('确定要导入数据吗？这将覆盖当前的所有设置。')) {
                return;
            }

            await chrome.storage.sync.clear();
            await chrome.storage.sync.set(importData.data);

            this.showNotification('数据导入成功，页面将刷新', 'success');
            
            // 刷新页面以应用新设置
            setTimeout(() => {
                window.location.reload();
            }, 2000);

        } catch (error) {
            console.error('导入数据失败:', error);
            this.showNotification('导入数据失败，请检查文件格式', 'error');
        }
    }

    async clearAllData() {
        if (!confirm('确定要清除所有数据吗？这将删除所有设置和令牌，此操作无法撤销。')) {
            return;
        }

        if (!confirm('请再次确认：这将完全重置扩展到初始状态。')) {
            return;
        }

        try {
            await chrome.storage.sync.clear();
            this.showNotification('所有数据已清除，页面将刷新', 'info');
            
            setTimeout(() => {
                window.location.reload();
            }, 2000);

        } catch (error) {
            console.error('清除数据失败:', error);
            this.showNotification('清除数据失败', 'error');
        }
    }

    showNotification(message, type = 'info') {
        const notification = document.getElementById('notification');
        notification.textContent = message;
        notification.className = `notification ${type}`;
        
        // 显示通知
        setTimeout(() => notification.classList.add('show'), 100);
        
        // 自动隐藏
        setTimeout(() => {
            notification.classList.remove('show');
        }, 4000);
    }
}

// 启动选项页面
document.addEventListener('DOMContentLoaded', () => {
    new PasswordManagerOptions();
});
